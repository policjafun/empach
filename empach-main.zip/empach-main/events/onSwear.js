const client = require('../')
const Discord = require('discord.js')
const isCMD = require('../helpers/isCMD')

client.on('messageCreate', async message => {
    if(!isCMD.check(message.client, message)) return console.log('ocm');
    if(message.author.bot) return;
    if(message.channel.isDMBased()) return;
    if(message.member.permissions.has('ManageMessages')) return;

    if(await (client.db.swear.findOne({ id: message.guild.id }))) {
        let data = await client.db.swear.findOne({ id: message.guild.id })
        if(!data.swears) return;

        if(!require('../data/swears.json').some(word => message.content.toLowerCase().includes(word))) return;

        let embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(`*${message.member}, you can't swear here!*`)

        message.channel.send({
            embeds: [embed]
        }).then(msg => {
            setTimeout(() => {
                msg.delete()
            }, 5000)
        })

        message.delete()
    }
})