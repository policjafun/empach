const { EmbedBuilder, ActionRowBuilder, ButtonStyle } = require('discord.js');
const client = require('..');
const { ButtonBuilder } = require('discord-gamecord/utils/utils');

function vars(x, member) {
    return (
        x
            .replaceAll('{member}', member)
            .replaceAll('{member.tag}', member.user.tag)
            .replaceAll('{member.username}', member.user.username)
            .replaceAll(
                '{member.avatar}',
                member.user.avatarURL({ dynamic: true })
            )
            .replaceAll('{member.joinedTimestampRelative}', `<t:${parseInt(member.joinedTimestamp / 1000)}:R>`)
            .replaceAll('{member.createdTimestampRelative}', `<t:${parseInt(member.user.createdTimestamp / 1000)}:R>`)
            .replaceAll('{member.joinedTimestampFullDate}', `<t:${parseInt(member.joinedTimestamp / 1000)}:f>`)
            .replaceAll('{member.createdTimestampFullDate}', `<t:${parseInt(member.user.createdTimestamp / 1000)}:f>`)
            .replaceAll('{guild.icon}', member.guild.iconURL({ dynamic: true }))
            .replaceAll('{guild.memberCount}', member.guild.members.cache.filter(m => !m.user.bot).size)
            .replaceAll('{guild.name}', member.guild.name) ||
        `${member} joined.`
    );
}

client.on('guildMemberRemove', async (member) => {
    if(member.user.bot) return;
    const db = client.db.goodbye;

    let data = await db.findOne({
        id: member.guild.id,
        status: true,
    });

    if (!data || !data.channel) return;

    const channel = await member.guild.channels.fetch(data.channel);

    if(!channel) return;

    const embed = new EmbedBuilder()
        .setColor(client.config.color)
        .setDescription(vars(data.message, member) || `Goodbye ${member}!`);

    const button = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setStyle(ButtonStyle.Primary)
                .setDisabled(true)
                .setLabel(`Users: ${member.guild.memberCount}`)
                .setCustomId('membercount')

        )

    channel.send({
        embeds: [embed],
        components: [button]
    });
});

client.on('guildMemberAdd', async (member) => {
    if(member.user.bot) return;
    const db = client.db.welcomer;

    let data = await db.findOne({
        id: member.guild.id,
        status: true,
    });

    if (!data || !data.channel) return;

    const channel = await member.guild.channels.fetch(data.channel);

    if(!channel) return;

    const button = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setStyle(ButtonStyle.Primary)
                .setDisabled(true)
                .setLabel(`Users: ${member.guild.memberCount}`)
                .setCustomId('membercount')

        )

    const embed = new EmbedBuilder()
        .setColor(client.config.color)
        .setDescription(vars(data.message, member) || `Welcome ${member}!`);

    channel.send({
        embeds: [embed],
        components: [button]
    });
});
