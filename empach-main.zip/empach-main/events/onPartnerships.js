const isCMD = require('../helpers/isCMD')
const client = require('../index')
const Discord = require('discord.js')

client.on('messageCreate', async message => {
    if(!isCMD.check(message.client, message)) return;
    if(message.author.bot) return;
    if(message.channel.isDMBased()) return;

    let data = await client.db.partnerships.findOne({
        id: message.guild.id
    })

    let userData = await client.db.userPartner.findOne({
        id: message.author.id
    })

    if(!data) {
        data = await client.db.partnerships.create({
            id: message.guild.id,
            status: false,
            channel: null,
            message: null,
            count: 0
        })
    }

    if(!data.status || !data.channel || !data.message) return;

    if(message.channel.id != data.channel) return;

    if(!message.content.toLowerCase().includes('discord.gg/')) return;

    if(!data.count) {
        data.count = 0
    }

    data.count += 1
    await data.save()

    if(!userData) {
        userData = await client.db.userPartner.create({
            id: message.author.id,
            count: 0
        })
    }

    userData.count += 1

    await userData.save()

    let embed = new Discord.EmbedBuilder()
        .setColor(client.config.color)
        .setDescription(data.message)
        .setFooter({
            text: `Partner #${data.count}\nUser partner #${userData.count}`
        })

    message.reply({
        embeds: [embed]
    })
})