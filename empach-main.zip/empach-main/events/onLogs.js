const client = require('..')

client.on('guildCreate', async (guild) => {
    let guild1 = await client.guilds.fetch("1087007065442103417")
    let channel = await guild1.channels.fetch("1088183304785760266")

    channel.send({
        content:
            `\`\`\`fix\nNew guild! (${client.guilds.cache.size})\n\n- Name: ${guild.name}\n- Owner: ${guild.ownerId}\n- Members: ${guild.memberCount}\`\`\``
    })
})

client.on('guildDelete', async (guild) => {
    let guild1 = await client.guilds.fetch("1087007065442103417")
    let channel = await guild1.channels.fetch("1088183304785760266")

    channel.send({
        content:
            `\`\`\`fix\nGuild removed! (${client.guilds.cache.size})\n\n- Name: ${guild.name}\n- Owner: ${guild.ownerId}\n- Members: ${guild.memberCount}\`\`\``
    })
})