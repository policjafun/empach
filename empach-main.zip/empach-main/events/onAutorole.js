const client = require('../')

client.on('guildMemberAdd', async (member) => {
    const config = await client.db.autorole.findOne({
        id: member.guild.id
    })

    if(!config || config.roles == []) return;

    config.roles
        .forEach(
            role => {
                try {
                    member.roles.add(role)
                } catch(e){}
            }
        )
})