const { ActivityType } = require('discord.js');
const client = require('..');
const chalk = require('chalk');

client.on('ready', () => {
    
    client.user.setActivity({
        name: `@${client.user.username} | pls help`,
        type: ActivityType.Listening
    });

    console.log(chalk.red(`Logged in as ${client.user.tag}!`));

    client.guilds.fetch('1073517304299659344').then((g) => {
        g.emojis.cache.forEach(
            (e) => {
                client.emoji[e.name] = `<:${e.identifier}>`
            }
        );
    });

    client.application.commands.set([])
});
