const client = require('..');
const { Captcha } = require('captcha-canvas');
const {
    AttachmentBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    ComponentType,
} = require('discord.js');

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;
    if (!interaction.customId.startsWith('role:')) return;

    let [name, role] = interaction.customId.split(':');

    if (interaction.member.roles.cache.has(role)) return interaction.reply({
        content: 'You are already verified!',
        ephemeral: true
    })

    const captcha = new Captcha();
    captcha.async = true;
    captcha.addDecoy();
    captcha.drawTrace();
    captcha.drawCaptcha();

    interaction.reply({
        content: "Check DM's",
        ephemeral: true
    })

    const attach = new AttachmentBuilder(await captcha.png, {
        name: 'captcha.png',
    });

    function getRandomCaptcha(length) {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(
                Math.floor(Math.random() * charactersLength)
            );
        }
        return result;
    }

    function getRandomArbitrary(min, max) {
        return Math.floor(Math.random() * max) + min;
    }

    let order = parseInt(getRandomArbitrary(1, 4));

    const row = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId(`verifyCaptchaSelect`)
            .setPlaceholder('Nothing selected')
            .setMaxValues(1)
            .setMinValues(1)
    );

    for (var i = 1; i <= 5; i++) {
        if (order === i) {
            row.components[0].addOptions({
                label: captcha.text,
                value: captcha.text,
            });
        } else {
            row.components[0].addOptions({
                label: getRandomCaptcha(6),
                value: getRandomCaptcha(3),
            });
        }
    }

    let msg = await interaction.member.send({
        files: [attach],
        components: [row],
    });
    const collector = msg.channel.createMessageComponentCollector({
        componentType: ComponentType.SelectMenu,
        time: 15000,
    });

    let isSelected = false;

    collector.on('collect', (i) => {
        if (i.user.id === interaction.user.id) {
            if (i.values.includes(captcha.text)) {
                interaction.member.roles.add(role);
                msg.edit({
                    content: 'Successfully verified!',
                    files: [],
                    components: [],
                });
            } else {
                msg.edit({
                    content: 'Wrong captcha selected! Try again.',
                    files: [],
                    components: [],
                });
            }
            isSelected = true;
        }
    });

    collector.on('end', (i) => {
        if (isSelected === true) return;
        msg.edit({
            content: 'No captcha selected in time. Try again',
            files: [],
            components: [],
        });
    });
});
