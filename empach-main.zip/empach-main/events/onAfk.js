const client = require('../');
const { EmbedBuilder } = require('discord.js');

client.on('messageCreate', async (message) => {
    if(!message.guild) return;
    if(await client.isCmd(message)) return;

    const afk = client.db.afk;
    let data = await afk.findOne({
        guild: message.guild.id,
        user: message.author.id,
    });
    if (!data || data.isAfk === false) return;

    (data.isAfk = false), data.save();
    const embed = new EmbedBuilder()
        .setColor(client.config.color)
        .setAuthor({
            name: message.author.tag,
            iconURL: message.author.avatarURL({ dynamic: true }),
        })
        .setDescription(
            `*Welcome back from afk ${message.author}*`
        )
        .addFields([
            {
                name: 'details',
                value: `・${data.reason}\n・<t:${data.timestamp}:R>`,
            },
        ]);
    return message.reply({
        embeds: [embed],
    });
});

client.on('messageCreate', async (message) => {
    if (await client.isCmd(message)) return;

    const afk = client.db.afk;

    if (!message.mentions.members?.first()) return;
    let data = await afk.findOne({
        guild: message.guild.id,
        user: message.mentions.members.first().id,
    });
    if (!data || data.isAfk === false) return;

    const embed = new EmbedBuilder()
        .setColor(client.config.color)
        .setAuthor({
            name: message.author.tag,
            iconURL: message.author.avatarURL({ dynamic: true }),
        })
        .setDescription(
            `*${
                message.author
            }, ${message.mentions.members.first()} is afk!*`
        )
        .addFields([
            {
                name: 'details',
                value: `・${data.reason}\n・<t:${data.timestamp}:R>`,
            },
        ]);
    return message.reply({
        embeds: [embed],
    });
});
