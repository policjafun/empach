const client = require('../')

client.on('messageDelete', async (message) => {
    const snipeDb = client.db.snipes;
    if(!message.author) return;
    if(message.embeds[0]) return;
    let m = await snipeDb.findOne({ id: message.guild.id, channel: message.channel.id })
    if(m === null) {
        m = new snipeDb({
            id: message.guild.id,
            channel: message.channel.id
        })
    }
    m.message = message.content
    m.user = message.author.id
    m.lastUsed = Math.floor(Date.now() / 1000)
    await m.save()
})