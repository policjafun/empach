const client = require('..');
const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
} = require('discord.js');

client.on('messageCreate', async (message) => {
    const mention = new RegExp(`^<@!?${client.user.id}>( |)$`, 'g');
    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setLabel('support')
            .setStyle(ButtonStyle.Link)
            .setURL('https://discord.gg/pW9eXNNmyf'),

        new ButtonBuilder()
            .setLabel('invite')
            .setStyle(ButtonStyle.Link)
            .setURL(
                'https://discord.com/api/oauth2/authorize?client_id=1084220649964310648&permissions=8&scope=bot'
            ),

        new ButtonBuilder()
            .setLabel('website')
            .setStyle(ButtonStyle.Link)
            .setURL('https://empach.wtf/?source=mention')
            .setDisabled(true)
    );

    let prefix = await client.db.prefix.findOne({ guildId: message.guildId });

    const embed = new EmbedBuilder()
        .setDescription(
            `・hello, im [${
                client.user.username
            }](https://discord.com/api/oauth2/authorize?client_id=1084220649964310648&permissions=8&scope=bot), general multipurpose discord bot that will help your server gain members.\n・my prefixes: \`${
                prefix?.prefixes?.join("`, `") || 'pls'
            }\` or <@${client.user.id}>\n・at this moment i have **${
                client.commands.size
            }** commands.`
        )
        .setColor(client.config.color);
    if (message.content.match(mention)) {
        message.reply({
            embeds: [embed],
            components: [row],
        });
    }
});
