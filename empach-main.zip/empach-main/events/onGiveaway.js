const client = require('../')

client.giveawaysManager.on('endedGiveawayReactionAdded', (giveaway, member, reaction) => {
    return reaction.users.remove(member.user);
});