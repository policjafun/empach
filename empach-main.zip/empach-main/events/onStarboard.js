const client = require('../');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');

['messageReactionAdd', 'messageReactionRemove'].forEach((event) => {
    client.on(event, async (reaction) => {
        if (reaction.emoji.name !== '⭐') return;
        if (reaction.partial) await reaction.fetch();

        const data = await client.db.starboard.findOne({
            guild: reaction.message.guild.id,
        });

        if (!data) return;

        const channel = await reaction.message.guild.channels.fetch(
            data.channel
        ).catch(() => {})

        if(!channel) return;

        if (
            !reaction.message.reactions.cache
                .filter((f) => f.emoji.name === '⭐')
                .toJSON()[0]?.count
            ||
            data.count >
            reaction.message.reactions.cache
                .filter((f) => f.emoji.name === '⭐')
                .toJSON()[0].count
        ) {
            const messages = await channel.messages.fetch({ limit: 100 });

            let message = null;
            messages.forEach((msg) => {
                if (
                    msg?.embeds?.[0]?.fields?.[0]?.value ===
                    `[\`Click!\`](${reaction.message.url})`
                ) {
                    message = msg;
                }
            });

            return message ? message.delete() : false;
        }

        const messages = await channel.messages.fetch({ limit: 100 });

        let message = null;
        messages.forEach((msg) => {
            if (
                msg?.embeds?.[0]?.fields?.[0]?.value ===
                `[\`Click!\`](${reaction.message.url})`
            ) {
                message = msg;
            }
        });

        const embed = new EmbedBuilder()
            .setAuthor({
                name: reaction.message.author.tag,
                iconURL: reaction.message.author.displayAvatarURL({
                    dynamic: true,
                }),
            })
            .setDescription(
                `${reaction.message.content || 'No message content'}`
            )
            .addFields([
                {
                    name: `Jump to message`,
                    value: `[\`Click!\`](${reaction.message.url})`,
                },
            ])
            .setColor(client.config.color);
        if (reaction.message.attachments.size > 0) {
            const attachment = new AttachmentBuilder(
                reaction.message.attachments.first().url
            ).setName('starboard.png');

            embed.setImage('attachment://starboard.png');
            const payload = {
                embeds: [embed],
                content: `⭐ **${
                    reaction.message.reactions.cache
                        .filter((f) => f.emoji.name === '⭐')
                        .toJSON()[0].count
                }**`,
                files: [attachment],
            };

            return message ? message.edit(payload) : channel.send(payload);
        }
        if(reaction.message?.embeds[0]?.description) {
            embed.addFields([
                {
                    name:'Embed Content',
                    value: reaction.message.embeds[0].description
                }
            ])
        }
        const payload = {
            embeds: [embed],
            content: `⭐ **${
                reaction.message.reactions.cache
                    .filter((f) => f.emoji.name === '⭐')
                    .toJSON()[0].count
            }**`,
        };
        message ? message.edit(payload) : channel.send(payload);
    });
});
