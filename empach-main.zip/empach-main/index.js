const {
    Client,
    GatewayIntentBits,
    Partials,
    Collection,
} = require('discord.js');
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
    ],
    partials: [
        Partials.Channel,
        Partials.Message,
        Partials.User,
        Partials.GuildMember,
        Partials.Reaction,
    ],
    allowedMentions: {
        repliedUser: false,
    },
    ws: {
        properties: {
            browser: "Discord iOS"
        }
    }
});

const fs = require('fs');
require('dotenv').config(); // remove this line if you are using replit

const mongoose = require('mongoose');

mongoose.set('strictQuery', true);

mongoose.connect(
    process.env.MONGOOSE
);


client.commands = new Collection();
client.aliases = new Collection();
client.buttons = new Collection();
client.db = {};
client.disabledCommands = [];
client.maintenance = false
client.config = require('./config');
const { GiveawaysManager } = require('discord-giveaways');
const manager = new GiveawaysManager(client, {
    storage: './data/giveaways.json',
    default: {
        botsCanWin: false,
        embedColor: client.config.color,
        embedColorEnd: client.config.color,
        reaction: '🎉',
    },
});
client.giveawaysManager = manager;

module.exports = client;

fs.readdirSync('./handlers').forEach((handler) => {
    require(`./handlers/${handler}`)(client);
});

process.on('unhandledRejection', (reason, p) => {
    console.error(reason, p);
});
process.on('uncaughtException', (err, origin) => {
    console.error(err, origin);
});

client.login(process.env.TOKEN);