const Discord = require('discord.js');
const ms = require('ms');
module.exports = {
    name: 'gstart',
    aliases: ['start'],
    description: 'Start a giveaway.',
    userPerms: ['ManageGuild'],
    botPerms: [],
    usage: ['gstart <#channel> <duration> <winners> <title>'],
    run: async (client, message, args) => {
        try {
            if (!args[3]) return args.usage('gstart');

            let channel = message.mentions.channels.first();
            let duration = ms(args[1]);
            let winners = parseInt(args[2]);
            let title = args.slice(3).join(' ');

            if (!channel || !duration || !winners || !title)
                return args.usage('gstart');

            client.giveawaysManager.start(channel, {
                duration,
                prize: title,
                winnerCount: winners,
                hostedBy: message.author,
                messages: {
                    giveaway: null,
                    giveawayEnded: null,
                    inviteToParticipate: `React with to participate!`,
                },
            });
        } catch (e) {
            args.usage('gstart')
        }
    },
};
