const Discord = require('discord.js');
const ms = require('ms');
module.exports = {
    name: 'gdelete',
    aliases: ['delete'],
    description: 'Delete a giveaway.',
    userPerms: ['ManageGuild'],
    botPerms: [],
    usage: ['gdelete <message id>'],
    run: async (client, message, args) => {
        if(!args[0]) return args.usage("gdelete")
        try {
            await client.giveawaysManager.delete(args[0]);
            args.success("Deleted giveaway")
        } catch (e) {
            args.error('Something went wrong, possible causes:\n\nGiveaway not found')
        }
    },
};
