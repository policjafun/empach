const Discord = require('discord.js');
const ms = require('ms');
module.exports = {
    name: 'greroll',
    aliases: ['reroll'],
    description: 'Reroll a giveaway.',
    userPerms: ['ManageGuild'],
    botPerms: [],
    usage: ['greroll <message id>'],
    run: async (client, message, args) => {
        if(!args[0]) return args.usage("greroll")
        try {
            await client.giveawaysManager.reroll(args[0]);
        } catch (e) {
            args.error('Something went wrong, possible causes:\n\nThe giveaway is not ended\nGiveaway not found')
        }
    },
};
