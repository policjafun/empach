const Discord = require('discord.js');
const ms = require('ms');
module.exports = {
    name: 'gpause',
    description: 'Pause a giveaway.',
    userPerms: ['ManageGuild'],
    botPerms: [],
    usage: ['gpause <message id>'],
    run: async (client, message, args) => {
        if(!args[0]) return args.usage("gpause")
        try {
            await client.giveawaysManager.pause(args[0], {
                embedColor: client.config.color,
                content: "GIVEAWAY PAUSED! :warning:",
                infiniteDurationText: `---`
            });
        } catch (e) {
            args.error('Something went wrong, possible causes:\n\nThe giveaway is alredy paused\nGiveaway not found')
        }
    },
};
