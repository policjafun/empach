const Discord = require('discord.js');
const ms = require('ms');
module.exports = {
    name: 'gend',
    aliases: ['end'],
    description: 'End a giveaway.',
    userPerms: ['ManageGuild'],
    botPerms: [],
    usage: ['gend <message id>'],
    run: async (client, message, args) => {
        if(!args[0]) return args.usage("gend")
        try {
            await client.giveawaysManager.end(args[0]);
        } catch (e) {
            args.error('Something went wrong, possible causes:\n\nThe giveaway is alredy ended\nGiveaway not found')
        }
    },
};
