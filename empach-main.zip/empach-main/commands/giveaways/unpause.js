const Discord = require('discord.js');
const ms = require('ms');
module.exports = {
    name: 'gunpause',
    aliases: ['unpause'],
    description: 'Unpause a giveaway.',
    userPerms: ['ManageGuild'],
    botPerms: [],
    usage: ['gunpause <message id>'],
    run: async (client, message, args) => {
        if(!args[0]) return args.usage("gunpause")
        try {
            await client.giveawaysManager.unpause(args[0]);
        } catch (e) {
            args.error('Something went wrong, possible causes:\n\nThe giveaway is not paused\nGiveaway not found')
        }
    },
};
