const { MatchPairs } = require('discord-gamecord');
const Discord = require('discord.js');
module.exports = {
    name: 'pairs',
    description: 'Play a match-pairs!',
    userPerms: [],
    botPerms: [],
    usage: ['find-emoji'],
    run: async (client, message, args) => {
        let game = await client.db.gameWins.findOne({
            id: message.author.id,
        });

        let wins = 0;

        if (game?.pairs) wins = game.pairs;
        const Game = new MatchPairs({
            message: message,
            isSlashGame: false,
            embed: {
                title: client.emoji.agree + ' Match Pairs',
                color: client.config.color,
                description:
                    'Click on the buttons to match emojis with their pairs.\n' + `Your current win count: **${wins}**`,
            },
            timeoutTime: 60000,
            emojis: [
                '🍉',
                '🍇',
                '🍊',
                '🥭',
                '🍎',
                '🍏',
                '🥝',
                '🥥',
                '🍓',
                '🫐',
                '🍍',
                '🥕',
                '🥔',
            ],
            winMessage:
                'You won the Game! You turned a total of `{tilesTurned}` tiles.\n' + `Your current win count: **${wins + 1}**`,
            loseMessage:
                'You lost the Game! You turned a total of `{tilesTurned}` tiles.\n' + `Your current win count: **${wins}**`,
            playerOnlyMessage: 'Only {player} can use these buttons.',
        });

        Game.startGame();
        Game.on('gameOver', async (g) => {
            if (g.result === 'win') {
                if (!game) {
                    game = await client.db.gameWins.create({
                        id: message.author.id,
                        pairs: 0,
                    });
                }

                game.pairs += 1;
                await game.save();
            }
        });
    },
};
