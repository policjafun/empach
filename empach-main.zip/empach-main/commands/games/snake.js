const { Snake } = require('discord-gamecord');
const Discord = require('discord.js');
module.exports = {
    name: 'snake',
    description: 'Play a snake game!',
    userPerms: [],
    botPerms: [],
    usage: ['snake'],
    run: async (client, message, args) => {
        const Game = new Snake({
            message: message,
            isSlashGame: false,
            embed: {
                title: client.emoji.agree + ' Snake Game',
                overTitle: client.emoji.close + ' Game Over',
                color: client.config.color,
            },
            emojis: {
                board: '⬛',
                food: '🍎',
                up: '⬆️',
                down: '⬇️',
                left: '⬅️',
                right: '➡️',
            },
            stopButton: 'Exit',
            timeoutTime: 10000,
            snake: { head: '🟢', body: `🟩`, tail: `🟩`, over: '💀' },
            foods: ['🍎', '🍇', '🍊', '🥕', '🥝', '🌽'],
            playerOnlyMessage: 'Only {player} can use these buttons.',
        });

        Game.startGame();
    },
};
