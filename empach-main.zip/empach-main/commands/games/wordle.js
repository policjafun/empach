const { Wordle } = require('discord-gamecord');
const Discord = require('discord.js');
module.exports = {
    name: 'wordle',
    description: 'Play a wordle!',
    userPerms: [],
    botPerms: [],
    usage: ['wordle'],
    run: async (client, message, args) => {
        const Game = new Wordle({
            message: message,
            isSlashGame: false,
            embed: {
                title: client.emoji.agree + ' Wordle',
                color: client.config.color,
            },
            customWord: null,
            timeoutTime: 60000,
            winMessage: 'You won! The word was **{word}**.',
            loseMessage: 'You lost! The word was **{word}**.',
            playerOnlyMessage: 'Only {player} can use these buttons.',
        });

        Game.startGame();
        Game.on('gameOver', async (g) => {
            if(g.guessed.includes(g.word)) {
                let game = await client.db.gameWins.findOne({
                    id: message.author.id,
                });
                if (!game) {
                    game = await client.db.gameWins.create({
                        id: message.author.id,
                        wordle: 0,
                    });
                }
    
                game.wordle += 1;
                await game.save();
            }
        });
    },
};
