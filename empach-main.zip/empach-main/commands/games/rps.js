const { RockPaperScissors } = require('discord-gamecord');
const Discord = require('discord.js');
module.exports = {
    name: 'rps',
    description: 'Play a rock-paper-scissors!',
    userPerms: [],
    botPerms: [],
    usage: ['rps <@member>'],
    run: async (client, message, args) => {
        if (!message.mentions.users.first()) {
            return args.error('You need to mention a opponent');
        }

        const Game = new RockPaperScissors({
            message: message,
            isSlashGame: false,
            opponent: message.mentions.users.first(),
            embed: {
                title: client.emoji.agree + ' Rock Paper Scissors',
                color: client.config.color,
                description: 'Press a button below to make a choice.',
            },
            buttons: {
                rock: 'Rock',
                paper: 'Paper',
                scissors: 'Scissors',
            },
            emojis: {
                rock: client.emoji.rock,
                paper: client.emoji.paper,
                scissors: client.emoji.scissors,
            },
            mentionUser: true,
            timeoutTime: 60000,
            buttonStyle: 'SECONDARY',
            winMessage: '**{player}** won the Game! Congratulations!',
            tieMessage: 'The Game tied! No one won the Game!',
            timeoutMessage: 'The Game went unfinished! No one won the Game!',
            playerOnlyMessage:
                'Only {player} and {opponent} can use these buttons.',
        });

        Game.startGame();
        Game.on('gameOver', async (g) => {
            let winner =
                message.author.id == g.winner
                    ? message.author.id
                    : message.mentions.users.first().id;
            let game = await client.db.gameWins.findOne({
                id: winner,
            });
            if (!game) {
                game = await client.db.gameWins.create({
                    id: message.author.id,
                    rps: 0,
                });
            }

            game.rps += 1;
            await game.save();
        });
    },
};
