const { Minesweeper } = require('discord-gamecord');
const Discord = require('discord.js');
module.exports = {
    name: 'minesweeper',
    description: 'Play a minesweeper!',
    userPerms: [],
    botPerms: [],
    usage: ['minesweeper'],
    run: async (client, message, args) => {
        let game = await client.db.gameWins.findOne({
            id: message.author.id,
        });

        let wins = 0;

        if (game?.minesweeper) wins = game.minesweeper;
        const Game = new Minesweeper({
            message: message,
            isSlashGame: false,
            embed: {
                title: client.emoji.agree + ' Minesweeper',
                color: client.config.color,
                description:
                    'Click on the buttons to reveal the blocks except mines.\n' +
                    `Your current win count: **${wins}**`,
            },
            emojis: { flag: '🚩', mine: '💣' },
            mines: 5,
            timeoutTime: 60000,
            winMessage:
                'You won the Game! You successfully avoided all the mines.\n' +
                `Your current win count: **${wins + 1}**`,
            loseMessage:
                'You lost the Game! Beaware of the mines next time.\n' +
                `Your current win count: **${wins}**`,
            playerOnlyMessage: 'Only {player} can use these buttons.',
        });

        Game.startGame();
        Game.on('gameOver', async (g) => {
            if (g.result === 'win') {
                if (!game) {
                    game = await client.db.gameWins.create({
                        id: message.author.id,
                        minesweeper: 0,
                    });
                }

                game.minesweeper += 1;
                await game.save();
            }
        });
    },
};
