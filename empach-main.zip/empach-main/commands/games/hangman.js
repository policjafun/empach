const Discord = require('discord.js');
const { Hangman } = require('discord-gamecord');
module.exports = {
    name: 'hangman',
    description: 'Play a hangman!',
    userPerms: [],
    botPerms: [],
    usage: [
        'hangman <theme: nautre|sport|color|camp|fruit|discord|winter|pokemon>',
    ],
    run: async (client, message, args) => {
        if(!args[0] || !['nature', 'sport', "color", 'camp', 'fruit', 'discord', 'winter', 'pokemon'].includes(args[0].toLowerCase())) return args.usage('hangman')

        let game = await client.db.gameWins.findOne({
            id: message.author.id,
        });

        let wins = 0;

        if (game?.hangman) wins = game.hangman;

        const Game = new Hangman({
            message: message,
            isSlashGame: false,
            embed: {
                title: client.emoji.agree + ' Hangman',
                color: client.config.color,
                footer: `Currently you have ${wins} wins in this game`
            },
            hangman: {
                hat: '🎩',
                head: '😟',
                shirt: '👕',
                pants: '🩳',
                boots: '👞👞',
            },
            timeoutTime: 60000,
            theme: args[0].toLowerCase(),
            winMessage: `You won! The word was **{word}**.\nYour current win count: **${wins + 1}**`,
            loseMessage: `You lost! The word was **{word}**.\nYour current win count: **${wins}**`,
            playerOnlyMessage: 'Only {player} can use these buttons.',
        });

        Game.startGame();
        Game.on('gameOver', async (g) => {
            if (g.result === 'win') {
                if (!game) {
                    game = await client.db.gameWins.create({
                        id: message.author.id,
                        hangman: 0,
                    });
                }

                game.hangman += 1;
                await game.save();
            }
        });
    },
};
