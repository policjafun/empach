const { TwoZeroFourEight } = require('discord-gamecord');
const Discord = require('discord.js');
module.exports = {
    name: '2048',
    description: 'Play a 2048!',
    userPerms: [],
    botPerms: [],
    usage: ['2048'],
    run: async (client, message, args) => {
        const Game = new TwoZeroFourEight({
            message: message,
            isSlashGame: false,
            embed: {
                title: client.emoji.agree + ' 2048 Game',
                color: client.config.color,
            },
            emojis: {
                up: '⬆️',
                down: '⬇️',
                left: '⬅️',
                right: '➡️',
            },
            timeoutTime: 60000,
            buttonStyle: 'PRIMARY',
            playerOnlyMessage: 'Only {player} can use these buttons.',
        });

        Game.startGame();
    },
};
