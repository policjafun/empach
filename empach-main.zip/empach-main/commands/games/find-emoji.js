const { FindEmoji } = require('discord-gamecord');
const Discord = require('discord.js');
module.exports = {
    name: 'find-emoji',
    description: 'Play a find-emoji!',
    userPerms: [],
    botPerms: [],
    usage: ['find-emoji'],
    run: async (client, message, args) => {
        let game = await client.db.gameWins.findOne({
            id: message.author.id,
        });

        let wins = 0;

        if (game?.find_emoji) wins = game.find_emoji;

        const Game = new FindEmoji({
            message: message,
            isSlashGame: false,
            embed: {
                title: client.emoji.agree + ' Find Emoji',
                color: client.config.color,
                description:
                    'Remember the emojis from the board below.\n' +
                    `Your current win count: **${wins}**`,
                findDescription:
                    'Find the {emoji} emoji before the time runs out.',
            },
            timeoutTime: 60000,
            hideEmojiTime: 5000,
            buttonStyle: 'SECONDARY',
            emojis: ['🍉', '🍇', '🍊', '🍋', '🥭', '🍎', '🍏', '🥝'],
            winMessage:
                'You won! You selected the correct emoji. {emoji}\n' +
                `Your current win count: **${wins + 1}**`,
            loseMessage:
                'You lost! You selected the wrong emoji. {emoji}\n' +
                `Your current win count: **${wins}**`,
            timeoutMessage:
                'You lost! You ran out of time. The emoji is {emoji}\n' +
                `Your current win count: **${wins}**`,
            playerOnlyMessage: 'Only {player} can use these buttons.',
        });

        Game.startGame();
        Game.on('gameOver', async (g) => {
            if (g.selectedEmoji === g.correctEmoji) {
                if (!game) {
                    game = await client.db.gameWins.create({
                        id: message.author.id,
                        find_emoji: 0,
                    });
                }

                game.find_emoji += 1;
                await game.save();
            }
        });
    },
};
