const { TicTacToe } = require('discord-gamecord');
const Discord = require('discord.js');
module.exports = {
    name: 'tictactoe',
    aliases: ['ox'],
    description: 'Play a tictactoe!',
    userPerms: [],
    botPerms: [],
    usage: ['tictactoe <@member>'],
    run: async (client, message, args) => {
        if (!message.mentions.users.first()) {
            return args.error('You need to mention a opponent');
        }

        const Game = new TicTacToe({
            message: message,
            isSlashGame: false,
            opponent: message.mentions.users.first(),
            embed: {
                title: client.emoji.agree + ' TicTacToe Game',
                color: client.config.color,
                statusTitle: 'Status',
                overTitle: client.emoji.close + ' Game Over',
            },
            emojis: {
                xButton: client.emoji.close,
                oButton: client.emoji.o_,
                blankButton: client.emoji.blank,
            },
            mentionUser: true,
            timeoutTime: 60000,
            xButtonStyle: 'DANGER',
            oButtonStyle: 'SUCCESS',
            turnMessage: 'Its turn of player **{player}**.',
            winMessage: '**{player}** won the TicTacToe Game.',
            tieMessage: 'The Game tied! No one won the Game!',
            timeoutMessage: 'The Game went unfinished! No one won the Game!',
            playerOnlyMessage:
                'Only {player} and {opponent} can use these buttons.',
        });

        Game.startGame();
        Game.on('gameOver', async (g) => {
            let winner =
                message.author.id == g.winner
                    ? message.author.id
                    : message.mentions.users.first().id;
            let game = await client.db.gameWins.findOne({
                id: winner,
            });
            if (!game) {
                game = await client.db.gameWins.create({
                    id: message.author.id,
                    ox: 0,
                });
            }

            game.ox += 1;
            await game.save();
        });
    },
};
