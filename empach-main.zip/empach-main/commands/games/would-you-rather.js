const { WouldYouRather } = require('discord-gamecord');
const Discord = require('discord.js');
module.exports = {
    name: 'would-you-rather',
    aliases: ['wyr'],
    description: 'Play a would-you-rather!',
    userPerms: [],
    botPerms: [],
    usage: ['would-you-rather'],
    run: async (client, message, args) => {
        const Game = new WouldYouRather({
            message: message,
            isSlashGame: false,
            embed: {
                title: client.emoji.agree + ' Would You Rather',
                color: client.config.color,
            },
            buttons: {
                option1: 'Option 1',
                option2: 'Option 2',
            },
            timeoutTime: 60000,
            errMessage: 'Unable to fetch question data! Please try again.',
            playerOnlyMessage: 'Only {player} can use these buttons.',
        });

        Game.startGame();
    },
};
