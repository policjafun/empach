const { Slots } = require('discord-gamecord');
const Discord = require('discord.js');
module.exports = {
    name: 'slot',
    description: 'Play a slot machine!',
    userPerms: [],
    botPerms: [],
    usage: ['slot'],
    run: async (client, message, args) => {
        let game = await client.db.gameWins.findOne({
            id: message.author.id,
        });

        let wins = 0;

        if (game?.slot) wins = game.slot;
        const Game = new Slots({
            message: message,
            isSlashGame: false,
            embed: {
                title: client.emoji.agree + ' Slot Machine',
                color: client.config.color,
            },
            slots: ['🍇', '🍊', '🍋', '🍌'],
        });

        Game.startGame();
        Game.on('gameOver', async (g) => {
            if (g.result === 'win') {
                if (!game) {
                    game = await client.db.gameWins.create({
                        id: message.author.id,
                        slot: 0,
                    });
                }

                game.slot += 1;
                await game.save();
            }
        });
    },
};
