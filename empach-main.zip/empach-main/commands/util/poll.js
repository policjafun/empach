const Discord = require('discord.js');
module.exports = {
    name: 'poll',
    description: 'Creates poll in current channel',
    userPerms: ['ManageMessages'],
    botPerms: ['ManageMessages'],
    usage: [
        'poll <message> [--two|--three]',
    ],
    run: async (client, message, args) => {
        if(!args[0]) return args.usage('poll')
        let msg = args.join(' ');

        const yesNo = msg.includes(' --yes-or-no') || false;
        const two = msg.includes(' --two') || false;
        const three = msg.includes(' --three') || false;

        msg = msg.replace(' --yes-or-no', '')
            .replace(' --three', '')
            .replace(' --two', '');

        const embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(
                `*${message.member} created new poll*`
            )
            .addFields([
                {
                    name: 'details',
                    value: `・${msg}`,
                },
            ]);

        let sent = await message.reply({
            embeds: [embed],
        });

        if (yesNo) {
            sent.react(client.emoji.agree);
            sent.react(client.emoji.close);
        } else if (two) {
            sent.react('1️⃣');
            sent.react('2️⃣');
        } else if (three) {
            sent.react('1️⃣');
            sent.react('2️⃣');
            sent.react('3️⃣');
        } else {
            sent.react(client.emoji.agree);
            sent.react(client.emoji.close);
        }
    },
};
