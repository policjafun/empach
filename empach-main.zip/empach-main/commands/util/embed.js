const Discord = require('discord.js');
module.exports = {
    name: 'embed',
    description: 'Send a embed message',
    userPerms: ['ManageMessages'],
    botPerms: [],
    usage: [
        'embed <JSON> (you can generate it on website)',
    ],
    run: async (client, message, args) => {
        let msg = args.join(' ');
        if (!msg) return args.usage('embed');

        const deleteMessage = msg.includes(' --delete-message') || false;
        
        if (deleteMessage) {
            message.delete();
            msg = msg.replace(' --delete-message', '');
        }

        
        const embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
        
        try {
            let json = JSON.parse(msg);
    
            if(!json?.description) return args.error('You must provide a description for the embed');
            
            if(json.description) {
                embed.setDescription(json.description);
            }
            if(json.title) {
                embed.setTitle(json.title);
            }
            if(json.author) {
                embed.setAuthor(json.author);
            }
            if(json.footer) {
                embed.setFooter(json.footer);
            }
            if(json.image) {
                embed.setImage(json.image);
            }
            if(json.thumbnail) {
                embed.setThumbnail(json.thumbnail);
            }
            if(json.timestamp) {
                embed.setTimestamp();
            }
        } catch(e) {
            return args.error('Invalid JSON provided\nGenerate it on our website');
        }

        message.channel.send({
            embeds: [embed],
        })
    },
};
