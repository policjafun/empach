const translate = require("translate-google");
const Discord = require("discord.js");

module.exports = {
    name: 'translate',
    aliases: ['trans'],
    description: 'Translates a message.',
    userPerms: [],
    botPerms: [],
    usage: ['translate <language> <message>'],
    run: async (client, message, args) => {
        if(!args[1]) return args.usage('translate')
        let lang = args[0]

        let availableLanguages = [
            'af', 'sq', 'ar',  'hy',  'az', 'eu',    'be',
            'bn',   'bs', 'bg', 'ca',  'ceb', 'ny', 'zh-cn', 'zh-tw',
            'co',   'hr', 'cs', 'da',  'nl',  'en', 'eo',    'et',
            'tl',   'fi', 'fr', 'fy',  'gl',  'ka', 'de',    'el',
            'gu',   'ht', 'ha', 'haw', 'iw',  'hi', 'hmn',   'hu',
            'is',   'ig', 'id', 'ga',  'it',  'ja', 'jw',    'kn',
            'kk',   'km', 'ko', 'ku',  'ky',  'lo', 'la',    'lv',
            'lt',   'lb', 'mk', 'mg',  'ms',  'ml', 'mt',    'mi',
            'mr',   'mn', 'my', 'ne',  'no',  'ps', 'fa',    'pl',
            'pt',   'ma', 'ro', 'ru',  'sm',  'gd', 'sr',    'st',
            'sn',   'sd', 'si', 'sk',  'sl',  'so', 'es',    'su',
            'sw',   'sv', 'tg', 'ta',  'te',  'th', 'tr',    'uk',
            'ur',   'uz', 'vi', 'cy',  'xh',  'yi', 'yo',    'zu'
          ]

        if(!availableLanguages.includes(lang)){
            const embed = new Discord.EmbedBuilder()
                .setColor(client.config.color)
                .setDescription(
                    `*${message.member}, this language is not supported! Here is list of all supported languages:*\n\n\`${availableLanguages.join('`, `')}\``
                );

            return message.reply({
                embeds: [embed],
            });
        }

        let text = args.slice(1).join(' ')

        let translated = await translate(text, {to: lang}).then(res => {
            return args.success(res)
        }).catch(err => {
            args.error("An error occured while translating the message!")
            console.log(err)
        })
    }
}