const { EmbedBuilder, Client, BaseInteraction } = require('discord.js');
module.exports = {
	name: 'snipe',
    aliases: ['snipe-message'],
    description: 'Get last deleted message on actual channel',
    userPerms: [],
    botPerms: [],
    usage: ['snipe'],
	run: async (client, message, args) => {
        const snipeDb = client.db.snipes
		const data = await snipeDb.findOne({
			id: message.guild.id,
			channel: message.channel.id,
		});
		if (!data) {
			return args.error(`no deleted messages found on this channel.`)
		}
		let user = await client.users.fetch(data.user);
		const embed = new EmbedBuilder()
			.setColor(client.config.color)
			.addFields([{
                name: 'Last deleted message',
                value: `・\`${data.message || "no message content"}\`\n・${user}\n・<t:${data.lastUsed}:R>`
            }]);

		message.reply({
			embeds: [embed],
		});
	},
};