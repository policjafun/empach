const Discord = require('discord.js');

module.exports = {
    name: 'altfinder',
    aliases: ['alt'],
    description: 'Finds suspicious alt accounts',
    userPerms: ['ManageGuild'],
    botPerms: ['ManageGuild'],
    usage: ['altfinder'],
    /**
     * 
     * @param {Discord.Client} client 
     * @param {Discord.Message} message 
     * @param {Array} args 
     */
    run: async (client, message, args) => {
        await message.guild.members.fetch({force:true})
        const users = message.guild.members.cache.map(m => !m.user.bot && m.user);
        const alts = [];

        for (let i = 0; i < users.length; i++) {
            let user = users[i];
            if(!user) continue;
            if (user.createdTimestamp > Date.now() - 1000 * 60 * 60 * 24 * 7 && !user.avatar) {
                alts.push(user);
            }
        }

        const embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setTitle(`Found ${alts.length} suspicious alt accounts`)
            .setDescription(alts.map(u => u.tag).join('\n') || "No suspicious alts found");

        message.reply({
            embeds: [embed]
        })
    }

}