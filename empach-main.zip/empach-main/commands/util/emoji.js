const Discord = require('discord.js');

module.exports = {
    name: 'emoji',
    aliases: ['emote'],
    description: 'Get an emoji from the server',
    userPerms: [],
    botPerms: [],
    run: (client, message, args) => {
        let emoji = args[0];

        if(!emoji) return args.usage('emoji')

        let customemoji =
			client.emojis.cache.find((e) => e.id === emoji) ||
			client.emojis.cache.find((e) => e.name === emoji) ||
			Discord.parseEmoji(emoji) ||
			Discord.formatEmoji(emoji);

        if(customemoji.id) {
            const Link = `https://cdn.discordapp.com/emojis/${customemoji.id}.${
				customemoji.animated ? 'gif' : 'png'
			}`;

            const embed = new Discord.EmbedBuilder()
                .setColor(client.config.color)
                .setImage(Link)

            const row = new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                        .setStyle(5)
                        .setLabel('Download')
                        .setURL(Link),
                )

            

            message.reply({
                embeds: [embed],
                components: [row]
            });
        } else {
            return args.error('Please provide a valid emoji!')
        }
    }
}