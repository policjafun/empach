const Discord = require('discord.js');

module.exports = {
    name: 'lock',
    description: 'Locks a channel',
    usage: ['lock'],
    userPerms: ['ManageChannels'],
    botPerms: ['ManageChannels'],

    /**
     * 
     * @param {Discord.Client} client 
     * @param {Discord.Message} message 
     * @param {Array} args 
     */
    run: async (client, message, args) => {
        const channel = message.mentions.channels.first() || message.channel
        channel.permissionOverwrites.edit(message.guild.roles.everyone, {
            SendMessages: false,
            AddReactions: false
        })
        return args.success('Locked channel :lock:')
    }
}