const Discord = require('discord.js');
module.exports = {
    name: 'say',
    aliases: ['send'],
    description: 'Sends a bot message',
    userPerms: ['ManageMessages'],
    botPerms: [],
    usage: [
        'say <your message> [optional args: --delete-message|--show-author]',
    ],
    run: async (client, message, args) => {
        let msg = args.join(' ');
        if (!msg) return args.usage('say');

        const deleteMessage = msg.includes(' --delete-message') || false;
        const showAuthor = msg.includes(' --show-author') || false;

        if (deleteMessage) {
            message.delete();
            msg = msg.replace(' --delete-message', '');
        }
        if (showAuthor) {
            msg = msg.replace(' --show-author', '');
            msg += `\n\nSent by ${message.member}`
        }
        message.channel.send({
            content: msg,
        });
    },
};
