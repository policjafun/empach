const Discord = require('discord.js');

module.exports = {
    name: 'unlock',
    description: 'Locks a channel',
    usage: ['unlock'],
    userPerms: ['ManageChannels'],
    botPerms: ['ManageChannels'],

    /**
     * 
     * @param {Discord.Client} client 
     * @param {Discord.Message} message 
     * @param {Array} args 
     */
    run: async (client, message, args) => {
        const channel = message.mentions.channels.first() || message.channel
        channel.permissionOverwrites.edit(message.guild.roles.everyone, {
            SendMessages: true,
            AddReactions: true
        })
        return args.success('Unocked channel :unlock:')
    }
}