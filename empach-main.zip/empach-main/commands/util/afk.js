const Discord = require('discord.js');
module.exports = {
    name: 'afk',
    aliases: ['afk-manage'],
    description: 'Manage your afk status',
    userPerms: [],
    botPerms: [],
    usage: ['afk [reason]'],
    run: async (client, message, args) => {
        let db = client.db.afk;
        let data = await db.findOne({
            guild: message.guild.id,
            user: message.author.id,
        });
        if (!data)
            data = new db({
                guild: message.guild.id,
                user: message.author.id,
                isAfk: false,
            });
        if (data.isAfk === true) {
            data.isAfk = false;
            data.save();
            const embed = new Discord.EmbedBuilder()
                .setColor(client.config.color)
                .setAuthor({
                    name: message.author.tag,
                    iconURL: message.author.avatarURL({ dynamic: true }),
                })
                .setDescription(`*Welcome back from afk ${message.author}*`)
                .addFields([
                    {
                        name: "details",
                        value: `・${data.reason}\n・<t:${data.timestamp}:R>`
                    }
                ]);
            return message.reply({
                embeds: [embed]
            });
        }

        (data.isAfk = true),
            (data.reason =
                args.join(" ") || 'no reason provided'),
            (data.timestamp = Math.floor(Date.now() / 1000));
        data.save();

        const embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setAuthor({
                name: message.author.tag,
                iconURL: message.author.avatarURL({ dynamic: true }),
            })
            .setDescription(`*${message.author}, you went afk.*`)
            .addFields([
                {
                    name: "details",
                    value: `・${data.reason}\n・<t:${data.timestamp}:R>`
                }
            ]);
        return message.reply({
            embeds: [embed],
        });
    },
};
