const Mexp = require('math-expression-evaluator');
const math = new Mexp()
const Discord = require('discord.js');
module.exports = {
    name: 'math',
    aliases: ['eval-math'],
    description: 'Just math.',
    userPerms: [],
    botPerms: [],
    usage: ['math <query>'],
    run: async (client, message, args) => {
        if(!args[0]) return args.usage("math")
		let val;
		try {
			val = math.eval(args.join(' '));
		}
		catch (err) {
			return args.error(`Something went wrong:\n\n${err}`)
		}
        return args.success(`Successfully evaled expression:\n\n\`\`\`${val}\`\`\``)
    },
};
