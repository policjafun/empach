const Discord = require('discord.js');
const ms = require('ms');

const cooldown = new Discord.Collection()

module.exports = {
    name: 'rep',
    aliases: ['reputation'],
    description: 'Give reputation to someone',
    userPerms: [],
    botPerms: [],
    usage: ['rep <@user>'],
    run: async (client, message, args) => {
        let user = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        if(!user) return args.error('Please mention someone to give reputation to!')
        if(user.user.bot) return args.error('You cannot give reputation to a bot!')
        if(user.id === message.author.id) return args.error('You cannot give reputation to yourself!')

        
        let data = await client.db.rep.findOne({
            id: user.id
        })

        if(data?.givenTo?.includes(user.id)) return args.error('You have already given reputation to this user!')

        if(!data) {
            data = await client.db.rep.create({
                id: user.id,
                reps: 0
            })
        }

        if(cooldown.has(message.author.id)) {
            let time = Date.now() - cooldown.get(message.author.id)
            time = ms(900000 - time)
            return args.error(`You are on cooldown! Please wait \`${time}\` seconds`)
        }

        cooldown.set(message.author.id, Date.now())
        setTimeout(() => {
            cooldown.delete(message.author.id)
        }, 900000)

        data.reps += 1
        await data.save()

        let embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(`You have given reputation to ${user.user.tag}!`)
            .setFooter({
                text: `This user has now ${data.reps}ᵣ`
            })

        message.reply({
            embeds: [embed]
        })

        user.givenTo.push(user.id)
        await user.save()
    }
}