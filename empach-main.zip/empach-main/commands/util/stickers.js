const { EmbedBuilder, Client, PermissionsBitField } = require('discord.js');
module.exports = {
    name: 'sticker',
    aliases: [],
    description: 'Manage stickers on the server',
    userPerms: [PermissionsBitField.Flags.ManageEmojisAndStickers],
    botPerms: [PermissionsBitField.Flags.ManageEmojisAndStickers],
    usage: ['sticker <add|remove>'],
    run: async (client, message, args) => {
        if(!args[0])
            return args.usage("sticker")

        if(args[0] == "add"){
            let name = args[1]

            if(!name)
                return args.error("provide name of the sticker")

            if(!message.attachments.first())
                return args.error("provide image")

            try {
                await message.guild.stickers.create({
                    file: message.attachments.first().url,
                    name,
                    tags: "⚠️"
                })
                args.success(`Successful created new sticker \`${name}\``)
            } catch (err) {
                args.error("Cannot create sticker, maybe you reach the limit")
            }
        } else if (args[0] == "remove"){
            let name = args[1]
            if(!name)
                return args.error("Provide sticker name to delete")

            let stickers = await message.guild.stickers.fetch()

            let sticker = stickers.find(s => s.name == name)

            if(!sticker)
                return args.error("Cannot find emoji with this name")

            try {
                message.guild.stickers.delete(sticker)

                args.success(`Successful deleted \`${name}\``)
            } catch (err) {
                args.error("Cannot delete sticker, unknow error")
            }
        }
    },
};