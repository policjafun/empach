const Discord = require('discord.js');

module.exports = {
    name: 'partnerinfo',
    aliases: ['partner-info', 'pi'],
    description: 'Get information about a user partner count',
    userPerms: [],
    botPerms: [],
    usage: ['partnerinfo <@user>'],
    run: async (client, message, args) => {
        let user = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        if(!user) return args.error('Please mention someone to get partner information from!')

        let data = await client.db.userPartner.findOne({
            id: user.id,
            guildId: message.guild.id
        })

        if(!data) {
            data = await client.db.userPartner.create({
                id: user.id,
                guildId: message.guild.id,
                count: 0
            })
        }

        let embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(`**${user.user.tag}** has **${data.count}** partners!`)

        message.reply({
            embeds: [embed]
        })
    }
}