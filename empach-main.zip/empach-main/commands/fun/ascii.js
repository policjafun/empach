const Discord = require('discord.js');
const figlet = require('figlet')
module.exports = {
    name: 'ascii',
    aliases: ['asciiart', 'art'],
    description: 'Returns provided text in ascii art',
    userPerms: [],
    botPerms: [],
    usage: ['ascii <text>'],
    run: async (client, message, args) => {
        if (!args[0]) return args.usage('ascii');

        if (args.join(' ').length > 20) {
            const embed = new Discord.EmbedBuilder()
                .setColor('Red')
                .setDescription(
                    `${message.author}, maximum characters limit reached (20).`
                );
            return message.reply({
                embeds: [embed],
            });
        }

        figlet(args.join(" "), (err, data) => {
            message.reply({
                content: `\`\`\`${data}\`\`\``,
            })
        })
    },
};
