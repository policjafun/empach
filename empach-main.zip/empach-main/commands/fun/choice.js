const Discord = require('discord.js');

module.exports = {
    name: 'choice',
    aliases: ['choose'],
    description: 'Choose between multiple options',
    userPerms: [],
    botPerms: [],
    usage: ['choice <option1 | option2 | option3 | ...>'],
    run: async (client, message, args) => {
        if (!args[0]) return args.usage('choice')

        const options = args.join(' ').split(' | ');

        if (options.length < 2) args.error("You need to provide at least 2 options to choose from!")

        const embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(
                `*${message.member}, i choose:* **${options[Math.floor(Math.random() * options.length)]}**`
            );

        message.reply({
            embeds: [embed],
        });
    }
}