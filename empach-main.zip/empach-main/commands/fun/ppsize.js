const Discord = require('discord.js');
module.exports = {
    name: 'ppsize',
    aliases: ['pp'],
    description: 'Check user pp size',
    userPerms: [],
    botPerms: [],
    usage: ['ppsize [@user]'],
    run: async (client, message, args) => {
        let user;
        try {
            if (args[0]) {
                user =
                    message.mentions.users.first() ||
                    client.users.cache.find((u) =>
                        u.username.toLowerCase().includes(args[0].toLowerCase())
                    ) ||
                    (await client.users.fetch(args[0]));
            } else {
                user = message.author;
            }
        } catch (err) {
            const embed = new Discord.EmbedBuilder()
                .setColor('Red')
                .setDescription(
                    `*${message.member}, i cant find that user!*`
                );

            return message.reply({
                embeds: [embed],
            });
        }
        await user.fetch();
        
        let random = Math.floor(Math.random() * 10) + 1;
        let ppSize = "";

        for(let i = 0; i < random; i++) {
            ppSize += "="
        }

        const embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(client.getLocale(message, 'fun.ppsize:success', client.emoji.agree, user.id, ppSize))

        message.reply({
            embeds: [embed]
        })
    },
};
