const Discord = require('discord.js');
const figlet = require('figlet')
module.exports = {
    name: 'reverse',
    aliases: [],
    description: 'Returns reversed text',
    userPerms: [],
    botPerms: [],
    usage: ['reverse <text>'],
    run: async (client, message, args) => {
        if(!args[0])
            return args.usage("reverse")
        
        let reversed = args.join(" ").split(``).reverse().join(``)

        args.success(reversed)
    },
};
