const Discord = require(`discord.js`);

module.exports = {
    name: `prefix`,
    aliases: ['set-prefix'],
    description: `Add new prefixes or delete existing one`,
    usage: ['prefix add <prefix>', 'prefix remove <prefix>', 'prefix list'],
    run: async (client, message, args) => {
        if (!args[0]) return args.usage('prefix');

        let c = await client.db.prefix.findOne({
            guildId: message.guildId,
        });

        if (!c)
            c = await client.db.prefix.create({
                guildId: message.guildId,
                prefixes: ['pls'],
            });

        if (args[0] === `add`) {
            if (!args[1]) {
                return args.usage('prefix');
            }
            if (c.prefixes.includes(args[1])) {
                await c.save();
                return args.error("This prefix is alredy added!")
            }

            c.prefixes.push(args[1]);
            await c.save();

            args.success(`Added \`${args[1]}\` to prefix list`)
        } else if (args[0] === `list`) {
            await c.save();

            args.success(`List of prefixes: ${c.prefixes
                .map((x) => `\`${x}\``)
                .join(`, `)}`)
        } else if (args[0] === `remove`) {
            if (!c.prefixes.includes(args[1])) {
                await c.save();
                return args.error("Cannot find that prefix in list")
            }

            c.prefixes.pull(args[1]);
            await c.save();
            args.success(`Successfully removed prefix: \`${args[1]}\``)
        } else
            args.usage('prefix')
    },
};
