const Discord = require('discord.js');
module.exports = {
    name: 'starboard',
    aliases: ['sb'],
    description: 'Setup starboard system',
    userPerms: ['ManageGuild'],
    botPerms: ['Administrator'],
    usage: [
        'starboard enable <#channel> <emote count (from 1 to 50)>',
        'starboard disable',
        'starboard status',
    ],
    run: async (client, message, args) => {
        if (!args[0]) return args.usage('starboard');

        let config = await client.db.starboard.findOne({
            guild: message.guild.id,
        });

        switch (args[0]) {
            case 'disable':
                const embed = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription('Saved new changes!')
                    .addFields([
                        {
                            name: 'Changed config:',
                            value: `・channel: \`no channel set\`\n・emote count: \`no emote count set\``,
                        },
                    ]);

                message.reply({
                    embeds: [embed],
                });

                if (config) {
                    await client.db.starboard.deleteOne({
                        guild: message.guild.id,
                    });
                }
                break;
            case 'enable':
                if (
                    !args[2] ||
                    !message.mentions.channels.first() ||
                    !args[1].includes(message.mentions.channels.first()?.id) ||
                    isNaN(parseInt(args[2])) ||
                    parseInt(args[2]) > 50 ||
                    parseInt(args[2]) < 1
                )
                    return args.usage('starboard');

                if (!config) {
                    config = await client.db.starboard.create({
                        guild: message.guild.id,
                    });
                }

                (config.channel = message.mentions.channels.first()?.id),
                    (config.count = parseInt(args[2]));

                await config.save();
            case 'status':
                if (!config) {
                    const embed = new Discord.EmbedBuilder()
                        .setColor(client.config.color)
                        .setDescription('*Currently displays informations about current config*')
                        .addFields([
                            {
                                name: 'Changed config:',
                                value: `・channel: \`no channel set\`\n・emote count: \`no emote count set\``,
                            },
                        ]);

                    return message.reply({
                        embeds: [embed],
                    });
                } else {
                    const embed = new Discord.EmbedBuilder()
                        .setColor(client.config.color)
                        .setDescription('*Currently displays informations about current config*')
                        .addFields([
                            {
                                name: 'Changed config:',
                                value: `・channel: \`${config.channel}\`\n・emote count: \`${config.count}\``,
                            },
                        ]);

                    message.reply({
                        embeds: [embed],
                    });
                }
                break;
            default:
                return args.usage('starboard');
        }
    },
};
