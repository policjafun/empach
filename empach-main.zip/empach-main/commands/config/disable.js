const Discord = require('discord.js');
module.exports = {
    name: 'disable',
    aliases: ['off', 'toggle-off'],
    description: 'Disables command on current server',
    userPerms: ["ManageGuild"],
    botPerms: ["ManageGuild"],
    usage: ['disable <cmd name>'],
    run: async (client, message, args) => {
        if(!args[0]) return args.usage('disable')

        if(!client.commands.get(args[0])) return args.error("This command does not exists.")

        if(['disable', 'enable'].includes(args[0])){
            return args.error("You can't disable this command.")
        }

        let data = await client.db.command.findOne({
            id: message.guild.id
        })

        if(!data) {
            data = await client.db.command.create({
                id: message.guild.id,
                commands: []
            })
        }

        if(data.commands.includes(args[0])) {
            return args.error("This command is alredy disabled.")
        }

        data.commands.push(args[0])

        args.success(`Sucessfully disabled command \`${args[0]}\`.`)

        await data.save()
    },
};
