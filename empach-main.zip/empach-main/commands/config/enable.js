const Discord = require('discord.js');
module.exports = {
    name: 'enable',
    aliases: ['on', 'toggle-on'],
    description: 'Enables command on current server',
    userPerms: ["ManageGuild"],
    botPerms: ["ManageGuild"],
    usage: ['enable <cmd name>'],
    run: async (client, message, args) => {
        if(!args[0]) return args.usage('enable')

        if(!client.commands.get(args[0])) return args.error("This command does not exists.")

        let data = await client.db.command.findOne({
            id: message.guild.id
        })

        if(!data) {
            data = await client.db.command.create({
                id: message.guild.id,
                commands: []
            })
        }

        if(!data.commands.includes(args[0])) {
            return args.error("This command is alredy enabled.")
        }

        data.commands.pull(args[0])

        args.success(`Sucessfully enabled command \`${args[0]}\``)

        await data.save()
    },
};
