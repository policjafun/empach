const Discord = require('discord.js');
module.exports = {
    name: 'verify',
    aliases: ['verify-embed'],
    description: 'Send verification embed in channel',
    userPerms: [],
    botPerms: [],
    usage: ['verify <#channel> <@role> [message]'],
    run: async (client, message, args) => {
        if (
            !args[1] ||
            !message.mentions.channels.first() ||
            !message.mentions.roles.first()
        )
            return args.usage('verify');

        let channel = message.mentions.channels.first();
        let role = message.mentions.roles.first();
        let embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(
                args.slice(2).join(' ') || 'Click button below to verify'
            );

        let row = new Discord.ActionRowBuilder().setComponents(
            new Discord.ButtonBuilder()
                .setCustomId(`role:${role.id}`)
                .setStyle(Discord.ButtonStyle.Secondary)
                .setLabel("Verify")
        );

        channel.send({
            embeds: [embed],
            components: [row]
        })

        args.success("Embed sent.")
    },
};
