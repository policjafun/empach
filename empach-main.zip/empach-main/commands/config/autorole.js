const Discord = require('discord.js');
module.exports = {
    name: 'autorole',
    aliases: ['set-autorole', 'ar'],
    description: 'Manage autoroles',
    userPerms: ['ManageRoles'],
    botPerms: ['Administrator'],
    usage: ['autorole add <@role>', 'autorole remove <@role>', 'autorole list'],
    run: async (client, message, args) => {
        if (!args[0]) return args.usage('autorole');

        let configuration = await client.db.autorole.findOne({
            id: message.guild.id,
        });

        if (!configuration) {
            configuration = await client.db.autorole.create({
                id: message.guild.id,
                roles: [],
            });
        }

        switch (args[0]) {
            case 'add':
                if (!args[1]) return args.usage('autorole');

                let role = message.mentions.roles.first() || message.guild.roles.cache.find(r => r.name = args[1]) || message.guild.roles.cache.get(args[1])

                if (!role) {
                    return args.error("you need to provide role.")
                }

                if(!role.editable) {
                    return args.error("i cannot access this role, you need to make sure that my role is higher than mentioned role.")
                }

                if (configuration.roles.includes(role.id)) {
                    return args.error("this role is alredy added!")
                }

                if(configuration.roles.length >= 6) {
                    return args.error("you can add maximum 6 roles.")
                }

                configuration.roles.push(role.id);

                const changess = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription('Saved new changes!')
                    .addFields([
                        {
                            name: 'Changed config:',
                            value: `**・roles: \`${
                                configuration.roles.join("`, `") || "no roles found"
                            }\`**`,
                        },
                    ]);

                message.reply({
                    embeds: [changess],
                });

                await configuration.save()
                break;
            case 'remove':
                if (!args[1]) return args.usage('autorole');

                let roleToDel = message.mentions.roles.first() || message.guild.roles.cache.find(r => r.name = args[1]) || message.guild.roles.cache.get(args[1])

                if (!roleToDel) {
                    return args.error("you need to provide a role!")
                }
                if (!configuration.roles.includes(roleToDel.id)) {
                    return args.error("this role is not added")
                }

                configuration.roles.pull(roleToDel.id);

                const changes = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription('Saved new changes!')
                    .addFields([
                        {
                            name: 'Changed config:',
                            value: `**・roles: \`${
                                configuration.roles?.join("`, `") || "no roles found"
                            }\`**`,
                        },
                    ]);

                message.reply({
                    embeds: [changes],
                });

                await configuration.save()
                break;
            case 'list':
                const embed = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription('*current server configuration*')
                    .addFields([
                        {
                            name: 'config:',
                            value: `・roles: \`${
                                configuration.roles?.join("`, `") || "no roles found"
                            }\``,
                        },
                    ]);

                return message.reply({
                    embeds: [embed]
                })
            default:
                args.usage('autorole')
        }
    },
};
