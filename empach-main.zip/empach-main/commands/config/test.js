const Discord = require('discord.js')

module.exports = {
    name: 'test',
    description: 'Test if command is disabled or not',
    userPerms: ['ManageGuild'],
    botPerms: ['ManageGuild'],
    usage: ['test <command>'],
    run: async (client, message, args) => {
        if(!args[0]) return args.usage('test')

        if(!client.commands.get(args[0])) return args.error("This command does not exists.")

        let data = await client.db.command.findOne({
            id: message.guild.id
        })

        if(!data) {
            data = await client.db.command.create({
                id: message.guild.id,
                commands: []
            })
        }

        if(data.commands.includes(args[0])) {
            return args.success("This command is disabled.")
        } else {
            return args.success("This command is enabled.")
        }
    }
}