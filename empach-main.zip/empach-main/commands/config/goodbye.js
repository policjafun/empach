const Discord = require('discord.js');
const Goodbye = require('../../schemas/goodbye');
module.exports = {
    name: 'set-goodbye',
    aliases: ['goodbye', 'bye'],
    description: 'Manage goodbye messages',
    userPerms: ['ManageGuild'],
    botPerms: ['Administrator'],
    usage: [
        'set-goodbye',
        'set-goodbye channel <#channel>',
        'set-goodbye message <welcome message>',
        'set-goodbye status <on|off>',
    ],
    run: async (client, message, args) => {
        let configuration = await Goodbye.findOne({ id: message.guild.id });

        if (!configuration) {
            configuration = await Goodbye.create({
                id: message.guild.id,
                status: false,
                channel: null,
                message: null,
            });
        }

        switch (args[0]) {
            case 'channel':
                if (!message.mentions.channels.first()) {
                    return args.error('you need to mention a channel.');
                }

                const channel = message.mentions.channels.first();

                configuration.channel = channel.id;

                const embed = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription('Saved new changes!')
                    .addFields([
                        {
                            name: 'Changed config:',
                            value: `・status: \`${
                                configuration.status ? 'enabled' : 'disabled'
                            }\`\n・**channel: \`${
                                configuration.channel
                            }\`**\n・message: ${configuration.message}`,
                        },
                    ]);

                message.reply({
                    embeds: [embed],
                });
                await configuration.save();
                break;
            case 'message':
                if (!args[1]) {
                    return args.usage('set-goodbye');
                }

                if (args.slice(1).join(' ').length > 170) {
                    return args.error(
                        'you reached character limit, try using less chars (Limit is 170).'
                    );
                }
                configuration.message = args.slice(1).join(' ');

                const changes = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription('Saved new changes!')
                    .addFields([
                        {
                            name: 'Changed config:',
                            value: `・status: \`${
                                configuration.status ? 'enabled' : 'disabled'
                            }\`\n・channel: \`${
                                configuration.channel || 'no channel set'
                            }\`\n**・message: **${
                                configuration.message || 'no message set'
                            }`,
                        },
                    ]);

                message.reply({
                    embeds: [changes],
                });
                await configuration.save();
                break;
            case 'status':
                if (!args[1] || !['on', 'off'].includes(args[1])) {
                    return args.usage('set-goodbye')
                }

                configuration.status = args[1] == 'on' ? true : false;

                const changess = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription('Saved new changes!')
                    .addFields([
                        {
                            name: 'Changed config:',
                            value: `**・status: \`${
                                configuration.status ? 'enabled' : 'disabled'
                            }\`**\n・channel: \`${
                                configuration.channel || 'no channel set'
                            }\`\n・message: ${
                                configuration.message || 'no message set'
                            }`,
                        },
                    ]);

                message.reply({
                    embeds: [changess],
                });
                await configuration.save();
                break;
            default:
                const changesss = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription('Current server configuration')
                    .addFields([
                        {
                            name: 'Server configuration:',
                            value: `・status: \`${
                                configuration.status ? 'enabled' : 'disabled'
                            }\`\n・channel: \`${
                                configuration.channel || 'no channel set'
                            }\`\n・message: ${
                                configuration.message || 'no message set'
                            }`,
                        },
                    ])
                    .setFooter(
                        {
                            text: 'Use set-goodbye <channel|message|status> <value> to change settings',
                        }
                    )

                message.reply({
                    embeds: [changesss],
                });
        }
    },
};
