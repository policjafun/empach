module.exports = {
    name: 'jailconfig',
    aliases: ['jail-config', 'jail-configs', 'jailconfigs'],
    description: 'Set jail role',
    userPerms: ['ManageRoles'],
    botPerms: ['ManageRoles'],
    usage: ['jailconfig <role>', 'jailconfig disable'],
    run: async (client, message, args) => {

        if (args[0] === 'disable') {
            let data = await client.db.jailConfig.findOne({
                guildId: message.guild.id
            })

            if (!data) {
                data = await client.db.jailConfig.create({
                    guildId: message.guild.id,
                    jailRole: null
                })
            } else {
                data.jailRole = null
            }

            await data.save()

            return args.success(`Successfully disabled jail role`);
        }

        const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]);
        if (!role) return args.usage('jailconfig');

        let data = await client.db.jailConfig.findOne({
            guildId: message.guild.id
        })

        if (!data) {
            data = await client.db.jailConfig.create({
                guildId: message.guild.id,
                jailRole: role.id
            })
        } else {
            data.jailRole = role.id
        }

        await data.save()

        return args.success(`Successfully set jail role to ${role}`);
    }
}