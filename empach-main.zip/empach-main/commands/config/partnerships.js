const Discord = require('discord.js')

module.exports = {
    name: 'partnerships',
    aliases: ['partnership', 'partner'],
    description: 'Manage partnerships',
    userPerms: ['ManageGuild'],
    botPerms: [],
    usage: ['partnerships status <on|off>', 'partnerships channel <#channel>', 'partnerships message <message>'],
    run: async (client, message, args) => {
        let configuration = await client.db.partnerships.findOne({ id: message.guild.id })

        if (!configuration) {
            configuration = await client.db.partnerships.create({
                id: message.guild.id,
                status: false,
                channel: null,
                message: null
            })
        }

        switch (args[0]) {
            case 'status':
                if (!args[1]) {
                    return args.usage('partnerships')
                }

                if (args[1] === 'on') {
                    configuration.status = true
                } else if (args[1] === 'off') {
                    configuration.status = false
                } else {
                    return args.error('You need to specify `on` or `off`.')
                }

                const embed = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription('Saved new changes!')
                    .addFields([
                        {
                            name: 'Changed config:',
                            value: `**・status: \`${configuration.status ? 'enabled' : 'disabled'}\`**\n・channel: \`${configuration.channel}\`\n・message: ${configuration.message}`
                        }
                    ])

                message.reply({
                    embeds: [embed]
                })
                await configuration.save()
                break
            case 'channel':
                if (!message.mentions.channels.first()) {
                    return args.error('You need to mention a channel.')
                }

                const channel = message.mentions.channels.first()

                if (!channel) return args.usage('partnerships')

                configuration.channel = channel.id

                const embed2 = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription('Saved new changes!')
                    .addFields([
                        {
                            name: 'Changed config:',
                            value: `・status: \`${configuration.status ? 'enabled' : 'disabled'}\`\n・**channel: \`${configuration.channel}\`**\n・message: ${configuration.message}`
                        }
                    ])

                message.reply({
                    embeds: [embed2]
                })
                await configuration.save()
                break
            case 'message':
                if (!args[1]) {
                    return args.usage('partnerships')
                }

                configuration.message = args.slice(1).join(' ')

                const embed3 = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription('Saved new changes!')
                    .addFields([
                        {
                            name: 'Changed config:',
                            value: `・status: \`${configuration.status ? 'enabled' : 'disabled'}\`\n・channel: \`${configuration.channel}\`\n・**message: ${configuration.message}**`
                        }
                    ])

                message.reply({
                    embeds: [embed3]
                })
                await configuration.save()
                break
            default:
                return args.usage('partnerships')
        }
    }
}