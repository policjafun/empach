const Discord = require('discord.js');

module.exports = {
    name: 'anti-swears',
    aliases: ['swears', 'anti-swearing', 'anti-swear', 'swear'],
    description: 'Manage the anti-swearing system',
    userPerms: ['ManageGuild'],
    botPerms: [],
    usage: ['anti-swears <enable/disable>'],
    run: async (client, message, args) => {
        if(!args[0]) return args.usage('anti-swears')

        if(args[0] === 'enable') {
            let data = await client.db.swear.findOne({
                id: message.guild.id
            })

            if(!data) {
                data = await client.db.swear.create({
                    id: message.guild.id
                })
            }

            if(data.swears) {
                return args.error("Anti-swearing is already enabled.")
            }

            data.swears = true

            await data.save()

            args.success("Sucessfully enabled anti-swearing.")
        } else if(args[0] === 'disable') {
            let data = await client.db.swear.findOne({
                id: message.guild.id
            })

            if(!data) {
                data = await client.db.swear.create({
                    id: message.guild.id
                })
            }

            if(!data.swears) {
                return args.error("Anti-swearing is already disabled.")
            }

            data.swears = false

            await data.save()

            args.success("Sucessfully disabled anti-swearing.")
        } else {
            return args.usage('anti-swears')
        }
    }
}
