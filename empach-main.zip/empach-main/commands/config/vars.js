const Discord = require('discord.js');
module.exports = {
    name: 'vars',
    aliases: ['vars-lookup'],
    description: 'Show all vars',
    userPerms: [],
    botPerms: [],
    usage: ['vars'],
    run: async (client, message, args) => {
        const { member } = message;
        const embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(
                `*${message.member}, here is full list of vars to use in commands*`
            )
            .addFields([
                {
                    name: 'Welcome & Goodbye system',
                    value: `・**{member}**: User mention\n・**{member.tag}**: User tag\n・**{member.username}**: User username\n・**{member.avatar}**: User's avatar URL\n・**{member.createdTimestampRelative}**: Member's account creation timestamp (ex. <t:${parseInt(member.user.createdTimestamp / 1000)}:R>)\n・**{member.createdTimestampFullDate}**: Member's account creation timestamp (ex. <t:${parseInt(member.user.createdTimestamp / 1000)}:f>)\n・**{member.joinedTimestampRelative}**: Member's joined timestamp (ex. <t:${parseInt(member.joinedTimestamp / 1000)}:R>)\n・**{member.joinedTimestampFullDate}**: Member's joined timestamp (ex. <t:${parseInt(member.joinedTimestamp / 1000)}:f>)\n・**{guild.icon}**: Guild icon URL\n・**{guild.name}**: Guild name\n・**{guild.memberCount}**: Guild member count`,
                },
            ]);

        message.reply({
            embeds: [embed],
        });
    },
};
