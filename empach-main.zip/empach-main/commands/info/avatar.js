const Discord = require('discord.js');
module.exports = {
    name: 'avatar',
    aliases: ['av'],
    description: 'Display user profile picture',
    userPerms: [],
    botPerms: [],
    usage: ['avatar [@user]'],
    run: async (client, message, args) => {
        let user;
        try {
            if (args[0]) {
                user =
                    message.mentions.users.first() ||
                    client.users.cache.find((u) =>
                        u.username.toLowerCase().includes(args[0].toLowerCase())
                    ) ||
                    (await client.users.fetch(args[0]));
            } else {
                user = message.author;
            }
        } catch (err) {
            const embed = new Discord.EmbedBuilder()
                .setColor('Red')
                .setDescription(
                    `*${message.member}, i cant find that user!*`
                );

            return message.reply({
                embeds: [embed],
            });
        }
        await user.fetch();

        const embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setImage(user.avatarURL({dynamic:true, size: 4096}))
            .setDescription(`*[png](${user.avatarURL({format:'png'})})* | *[jpg](${user.avatarURL({format:'jpg'})})*${user.avatar.startsWith('a_') ? ` | *[gif](${user.avatarURL({dyanmic:true})})*`: ""}`)

        message.reply({
            embeds: [embed]
        })
    },
};
