const Discord = require('discord.js');
const weather = require('weather-js')
module.exports = {
    name: 'weather',
    aliases: [],
    description: 'Check weather info in provided location',
    usage: ['weather <location>'],
    run: async (client, message, args) => {
        if (!args[0]) return args.usage('weather')

        const location = args.join(' ');

        weather.find({ search: location, degreeType: 'C' }, function (err, result) {
            if (err) {
                console.log(err);
                return args.error('An error occurred while fetching the weather')
            }

            if (result.length === 0) {
                return args.error(`No results found for "${location}"`)
            }

            const current = result[0].current;
            const locationName = result[0].location.name;

            const weatherEmbed = new Discord.EmbedBuilder()
                .setColor(client.config.color)
                .setTitle(`Current weather for ${locationName}`)
                .setDescription(current.skytext)
                .addFields(
                    { name: 'Temperature', value: `・ ${current.temperature} °C`, inline: true },
                    { name: 'Feels like', value: `・ ${current.feelslike} °C`, inline: true },
                    { name: 'Humidity', value: `・ ${current.humidity}%`, inline: true },
                    { name: 'Wind', value: `・ ${current.winddisplay}`, inline: true }
                  );

            message.reply({ embeds: [weatherEmbed] });
        });
    },
};
