const Discord = require('discord.js');
module.exports = {
    name: 'topgame',
    aliases: ['tg-info'],
    description: 'Display top games wins',
    userPerms: [],
    botPerms: [],
    usage: [
        'topgame <game: find_emoji|hangman|minesweeper|pairs|rps|slot|ox|wordle>',
    ],
    run: async (client, message, args) => {
        if (
            !args[0] ||
            ![
                'find_emoji',
                'hangman',
                'minesweeper',
                'pairs',
                'rps',
                'slot',
                'ox',
                'wordle',
            ].includes(args[0])
        )
            return args.usage('topgame');
        let users = await client.db.gameWins.find();
        let lbArr = []
        const lb = await users
            .slice(0)
            .sort(({ [args[0]]: a }, { [args[0]]: b }) => b - a)
            .forEach(
                async (id, pos) => {
                    let IDD = await client.users.fetch(id.id)
                    lbArr.push(`**${pos + 1}.** \`${IDD.tag}\` - ${id[args[0]]} win(s)${
                        pos + 1 == 1 && id[args[0]] > 0 ? ` :fire:` : ''
                    }`)
                }
            );

        const newnew = lbArr.slice(0, 10);

        args.success(`*displaying top wins*\n\n${newnew.join('\n') || "No one has won yet!"}`)
    },
};