const { EmbedBuilder } = require('discord.js');
const Discord = require('discord.js');

module.exports = {
    name: 'userinfo',
    aliases: ['ui', 'user'],
    usage: ['userinfo [user: mention, id, username]'],
    description: 'Check informations about user.',
    run: async (client, message, args) => {
        let user;
        try {
            if (args[0]) {
                user =
                    message.mentions.users.first() ||
                    client.users.cache.find((u) =>
                        u.username.toLowerCase().includes(args[0].toLowerCase())
                    ) ||
                    (await client.users.fetch(args[0]));
            } else {
                user = message.author;
            }
        } catch (err) {
            const embed = new Discord.EmbedBuilder()
                .setColor('Red')
                .setDescription(
                    `*${message.member}, i cant find that user!*`
                );

            return message.reply({
                embeds: [embed],
            });
        }
        await user.fetch();
        const guildMember = message.guild.members.cache.get(user.id);
        const embed = new EmbedBuilder().setAuthor({
            name: user.tag,
            iconURL: user.displayAvatarURL({ dynamic: true }),
        });

        const bdg = await client.db.badges.findOne({
            id: user.id,
        });

        let reps = await client.db.rep.findOne({
            id: user.id,
        })

        if(!reps) {
            reps = await client.db.rep.create({
                id: user.id,
                reps: 0
            })
        }

        if (!user.bot) {
            embed.addFields([
                {
                    name: 'Empach Badges',
                    value: `・${
                        bdg?.badges
                            .map(
                                (data) =>
                                    client.config.badges[data] ||
                                    'badge missing'
                            )
                            .join('\n・') || client.config.badges['user']
                    }`,
                },
            ]);
        }

        embed.addFields([
            {
                name: 'General',
                value: `・user: <@${user.id}>\n・is bot: ${
                    user.bot ? client.emoji.agree : client.emoji.close
                }\n・created: <t:${parseInt(
                    user.createdTimestamp / 1000
                )}:R> (<t:${parseInt(user.createdTimestamp / 1000)}:D>)\n・reps: \`${reps.reps || "0"}\``,
            },
        ]);

        if (guildMember) {
            embed.addFields([
                {
                    name: 'Guild',
                    value: `・display name: \`${
                        guildMember.displayName
                    }\`\n・joined: <t:${parseInt(
                        guildMember.joinedTimestamp / 1000,
                        10
                    )}:R> (<t:${parseInt(
                        guildMember.joinedTimestamp / 1000,
                        10
                    )}:D>)\n・roles **(${
                        guildMember.roles.cache.size - 1
                    })**: ${
                        guildMember.roles.cache
                            .sort((a, b) => b.position - a.position)
                            .map((r) => r.toString())
                            .slice(0, -1)
                            .join(' ') || `\`no roles found\``
                    }`,
                },
            ]);
        }

        let db = await client.db.gameWins.findOne({
            id: user.id,
        });

        let find_emoji = db?.find_emoji || 0;
        let hangman = db?.hangman || 0;
        let minesweeper = db?.minesweeper || 0;
        let pairs = db?.pairs || 0;
        let rps = db?.rps || 0;
        let slot = db?.slot || 0;
        let ox = db?.ox || 0;
        let wordle = db?.wordle || 0;

        embed.addFields([
            {
                name: 'Game Wins',
                value: `・find emoji: \`${find_emoji}\`\n・hangman: \`${hangman}\`\n・minesweeper: \`${minesweeper}\`\n・pairs: \`${pairs}\``,
                inline: true,
            },
        ]);

        embed.addFields([
            {
                name: '** **',
                value: `・rps: \`${rps}\`\n・slot: \`${slot}\`\n・tic-tac-toe: \`${ox}\`\n・wordle: \`${wordle}\``,
                inline: true,
            },
        ]);

        embed.addFields([
            {
                name: 'Links',
                value: `・[${
                    user.username
                }'s profile](https://discord.com/users/${user.id})\n・[${
                    user.username
                }'s avatar](${user.displayAvatarURL({ dynamic: true })})\n${
                    !user.banner
                        ? '** **'
                        : `・[${user.username}'s banner](${user.bannerURL({
                              dynamic: true,
                              size: 4096,
                          })})`
                }`,
                inline: false,
            },
        ]);

        embed
            .setColor(client.config.color)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }));

        if (user.banner) {
            let embed2 = new EmbedBuilder()
                .setColor(client.config.color)
                .setImage(user.bannerURL({ dynamic: true, size: 4096 }));
            message.reply({
                embeds: [embed, embed2],
            });
        } else {
            message.reply({
                embeds: [embed],
            });
        }
    },
};
