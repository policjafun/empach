const Discord = require('discord.js');
const fs = require('fs');
module.exports = {
    name: 'help',
    aliases: ['cmd', 'cmds', 'commands', 'h'],
    description: 'Check bot commands and its usage',
    usage: ['help [command]'],
    run: async (client, message, args) => {
        if (!args[0]) {
            let subCommands = 0
            let categories = [];

            fs.readdirSync('./commands/').forEach((dir) => {
                const commands = fs
                    .readdirSync(`./commands/${dir}/`)
                    .filter((file) => file.endsWith('.js'));

                const cmds = commands.map((command) => {
                    let file = require(`../../commands/${dir}/${command}`);

                    if (!file.name) return 'No command name.';

                    let name = file.name.replace('.js', '');

                    if(file.usage?.length !== undefined) subCommands += file.usage?.length

                    return `\`${name}\``;
                });

                let data = new Object();

                data = {
                    name: dir.charAt(0).toUpperCase() + dir.slice(1),
                    value: cmds.length === 0 ? 'In progress.' : cmds.join(', '),
                };

                categories.push(data);
            });

            const embed = new Discord.EmbedBuilder()
                .setTitle('Need help? Here are all of my commands:')
                .addFields(categories)
                .setDescription(
                    `Use \`${message.prefix}help\` followed by a command name to get more additional information on a command. For example: \`${message.prefix}help ping\`.\n・At this moment i have **${client.commands.size}** commands (**${subCommands}** with subcommands).`
                )
                .setColor(client.config.color);
            return message.reply({ embeds: [embed] });
        } else {
            const command =
                client.commands.get(args[0].toLowerCase()) ||
                client.commands.find(
                    (c) =>
                        c.aliases && c.aliases.includes(args[0].toLowerCase())
                );

            if (!command) {
                const embed = new Discord.EmbedBuilder()
                    .setDescription(
                        `*${message.author}, This command does not exists, try searching again using \`${message.prefix}help\`*`
                    )
                    .setColor('Red');
                return message.channel.send({ embeds: [embed] });
            }

            const embed = new Discord.EmbedBuilder()
                .setDescription('*here are command details;*')
                .setColor(client.config.color)
                .addFields([
                    {
                        name: 'Name',
                        value: `・\`${
                            command.name
                        }\`\n・Aliases: \`${command.aliases?.join('`, `') || "no aliases"}\``,
                    },
                    {
                        name: 'Usage',
                        value: `${
                            command?.usage
                                ?.map((u) => `・\`${u}\``)
                                .join('\n') || `・\`${command.name}\``
                        }`,
                    },
                    {
                        name: 'Description',
                        value: `・${command.description || "no description"}`,
                    }
                ])
                .setFooter({
                    text: 'Params:\n<> - Required | [] - Optional | <X | Y | Z> - Choose'
                })

            return message.channel.send({ embeds: [embed] });
        }
    },
};
