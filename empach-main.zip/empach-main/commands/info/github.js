const Discord = require('discord.js');
module.exports = {
    name: 'github',
    aliases: ['githubinfo', 'gi'],
    description: 'Github user info',
    userPerms: [],
    botPerms: [],
    usage: ['github <gh username>'],
    run: async (client, message, args) => {
        const user = args.join(' ');
        if (!user) {
            return args.usage('github')
        }
        fetch(`https://api.github.com/users/${user.toLowerCase()}`)
            .then((res) => res.json())
            .catch((err) => {
                console.log(err);
            })
            .then(async (u) => {
                if (u.message) {
                    const embed = new Discord.EmbedBuilder()
                        .setColor('Red')
                        .setDescription(
                            `*${message.member}, user not found!*`
                        );

                    return message.reply({
                        embeds: [embed],
                    });
                }
                const embed = new Discord.EmbedBuilder().setAuthor({
                    name: u.login,
                    iconURL: u.avatar_url,
                    url: u.html_url,
                });
                if (u.bio) {
                    embed.setDescription(`${u.bio}`);
                }
                embed
                    .addFields([
                        {
                            name: 'Global',
                            value: `・Created: <t:${
                                Date.parse(u.created_at) / 1000
                            }:R> (<t:${
                                Date.parse(u.created_at) / 1000
                            }:D>)\n・Public Repositories: \`${
                                u.public_repos
                            }\`\n・Followers: \`${
                                u.followers
                            }\`\n・Following: \`${u.following}\``,
                        },
                        {
                            name: 'Links',
                            value: `・[${u.login}'s profile](https://github.com/${u.login})\n・[${u.login}'s followers](https://github.com/${u.login}?tab=followers)\n・[${u.login}'s following](https://github.com/${u.login}?tab=following)\n・[${u.login}'s repositories](https://github.com/${u.login}?tab=repositories)\n・[${u.login}'s events](https://github.com/${u.login}?tab=events)`,
                        },
                    ])
                    .setThumbnail(u.avatar_url)
                    .setColor(client.config.color);
                message.reply({
                    embeds: [embed],
                });
            });
    },
};
