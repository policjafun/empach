const Discord = require('discord.js');
const axios = require('axios');
const lastFM = require('../../schemas/lastfm');

module.exports = {
    name: 'fm',
    description: 'Lastfm lookup',
    aliases: ['lastfm'],
    usage: [
        'fm',
        'fm connect <username>',
        'fm lasttrack',
        'fm toptracks',
        'fm topartists',
    ],
    cooldown: 3000,
    userPerms: [],
    botPerms: [],
    run: async (client, message, args) => {
        const fm_user = await lastFM.findOne({ id: message.author.id });

        if (args[0] !== 'connect' && !fm_user) {
            return args.error(`at first connect your last.fm account with bot using command \`${message.prefix}fm connect <username>\`.`)
        }

        switch (args[0]) {
            case 'connect':
                if (!args[1]) {
                    return args.usage('fm')
                }

                try {
                    const response = await axios.get(
                        'http://ws.audioscrobbler.com/2.0/',
                        {
                            params: {
                                api_key: client.config.lastfm.key,
                                method: 'user.getInfo',
                                user: args[1],
                                format: 'json',
                            },
                        }
                    );

                    const embed = new Discord.EmbedBuilder()
                        .setColor(client.config.color)
                        .setDescription(
                            `*${message.author}, successfully connected your __[last.fm](${response.data.user.url})__ account.*`
                        )
                        .setFooter({
                            text: 'Last updated:',
                        })
                        .setTimestamp()
                        .addFields([
                            {
                                name: 'Your stats',
                                value: `・scrobbles: ${response.data.user.playcount}\n・playlists: ${response.data.user.playlists}\n・artist count: ${response.data.user.artist_count}\n・country: ${response.data.user.country}`,
                            },
                        ]);

                    if (!fm_user) {
                        await lastFM.create({
                            id: message.author.id,
                            lastfm: args[1],
                        });
                    } else {
                        fm_user.lastfm = args[1];
                        fm_user.updatedAt = Math.floor(Date.now() / 1000);
                        await fm_user.save();
                    }

                    return message.reply({
                        embeds: [embed],
                    });
                } catch (error) {
                    console.log(error);
                    const embed = new Discord.EmbedBuilder()
                        .setColor('Red')
                        .setDescription(
                            `${message.author}, i can't find that user on \`last.fm\`, if you belive it's an error report this at our support discord server.`
                        );
                    return message.reply({
                        embeds: [embed],
                    });
                }
            case 'np':
            case 'nowplaying':
            case 'lasttrack':
                try {
                    const response = await axios.get(
                        'http://ws.audioscrobbler.com/2.0/',
                        {
                            params: {
                                api_key: client.config.lastfm.key,
                                method: 'user.getRecentTracks',
                                user: fm_user.lastfm,
                                format: 'json',
                            },
                        }
                    );

                    const response2 = await axios.get(
                        'http://ws.audioscrobbler.com/2.0/',
                        {
                            params: {
                                api_key: client.config.lastfm.key,
                                method: 'user.getInfo',
                                user: fm_user.lastfm,
                                format: 'json',
                            },
                        }
                    );

                    const data = response.data.recenttracks.track[0];
                    const embed = new Discord.EmbedBuilder()
                        .setColor(client.config.color)
                        .setDescription(
                            `${message.author}, your recent track info.`
                        )
                        .setThumbnail(data?.image[3]['#text'] || null)
                        .addFields([
                            {
                                name: data.name,
                                value: `by [${data.artist['#text']}](${data.url}) in [${data.album['#text']}](${data.url})`,
                            },
                        ]);
                    if (data['@attr']?.nowplaying === 'true') {
                        embed.setFooter({
                            text: `▶️ Currently playing・Scrobbles: ${response2.data.user.playcount}`,
                        });
                    } else {
                        embed.setFooter({
                            text: `⏹ Last played・Scrobbles: ${response2.data.user.playcount}`,
                        });
                    }

                    return message.reply({
                        embeds: [embed],
                    });
                } catch (error) {
                    console.log(error);
                    const embed = new Discord.EmbedBuilder()
                        .setColor('Red')
                        .setDescription(
                            `${message.author}, i can't find your \`last.fm\` account, try using command again or report this on our discord support server.`
                        );
                    return message.reply({
                        embeds: [embed],
                    });
                }
            case 'top':
            case 'tracks':
            case 'toptracks':
                try {
                    const response = await axios.get(
                        'http://ws.audioscrobbler.com/2.0/',
                        {
                            params: {
                                api_key: client.config.lastfm.key,
                                method: 'user.getTopTracks',
                                user: fm_user.lastfm,
                                format: 'json',
                            },
                        }
                    );

                    const nowplaying = await axios.get(
                        'http://ws.audioscrobbler.com/2.0/',
                        {
                            params: {
                                api_key: client.config.lastfm.key,
                                method: 'user.getRecentTracks',
                                user: fm_user.lastfm,
                                format: 'json',
                            },
                        }
                    );

                    const trackNp = nowplaying.data.recenttracks.track[0];

                    const data = response.data.toptracks.track;

                    const topTracks = data.slice(0, 25);

                    const pages = [];
                    const chunkSize = 5;
                    for (let i = 0; i < topTracks.length; i += chunkSize) {
                        const chunk = topTracks.slice(i, i + chunkSize);

                        const embed = new Discord.EmbedBuilder()
                            .setDescription(
                                `${message.author}, displaying top tracks.`
                            )
                            .setColor(client.config.color);

                        for (const track of chunk) {
                            embed.addFields([
                                {
                                    name: `${topTracks.some(
                                        () =>
                                            track.name === trackNp.name &&
                                            track.artist.name ===
                                            trackNp.artist['#text'] &&
                                            trackNp['@attr']?.nowplaying ==
                                            'true'
                                    )
                                            ? `▶️ `
                                            : ''
                                        }${track.name}`,
                                    value: `by ${track.artist.name
                                        }\nPlay count: ${track.playcount}${topTracks.some(
                                            () =>
                                                track.name === trackNp.name &&
                                                track.artist.name ===
                                                trackNp.artist['#text'] &&
                                                trackNp['@attr']?.nowplaying ==
                                                'true'
                                        )
                                            ? ' (+1)'
                                            : ''
                                        }・Duration: ${track.duration !== '0'
                                            ? `${track.duration} seconds`
                                            : 'NaN'
                                        }`,
                                },
                            ]);
                        }
                        pages.push(embed);
                    }

                    let row = new Discord.ActionRowBuilder().setComponents(
                        new Discord.ButtonBuilder()
                            .setCustomId(`page-back`)
                            .setStyle(2)
                            .setEmoji(client.emoji.left)
                            .setDisabled(true),
                        new Discord.ButtonBuilder()
                            .setCustomId(`page-close`)
                            .setStyle(4)
                            .setEmoji(client.emoji.close),
                        new Discord.ButtonBuilder()
                            .setCustomId(`page-next`)
                            .setStyle(2)
                            .setEmoji(client.emoji.right)
                            .setDisabled(true)
                    );

                    const msg = await message.reply({
                        embeds: [pages[0]],
                        components: [row],
                    });

                    return client.paginator(pages, 0, row, message, msg);
                } catch (error) {
                    console.log(error);
                    const embed = new Discord.EmbedBuilder()
                        .setColor('Red')
                        .setDescription(
                            `${message.author}, i can't find your \`last.fm\` account, try using command again or report this on our discord support server.`
                        );
                    return message.reply({
                        embeds: [embed],
                    });
                }
            case 'topartists':
            case 'ta':
            case 'artists':
                try {
                    const response = await axios.get(
                        'http://ws.audioscrobbler.com/2.0/',
                        {
                            params: {
                                api_key: client.config.lastfm.key,
                                method: 'user.getTopArtists',
                                user: fm_user.lastfm,
                                format: 'json',
                            },
                        }
                    );

                    const data = response.data.topartists.artist;

                    const topTracks = data.slice(0, 25);

                    const pages = [];
                    const chunkSize = 5;
                    for (let i = 0; i < topTracks.length; i += chunkSize) {
                        const chunk = topTracks.slice(i, i + chunkSize);

                        const embed = new Discord.EmbedBuilder()
                            .setDescription(
                                `${message.author}, displaying top artists.`
                            )
                            .setColor(client.config.color);

                        for (const track of chunk) {
                            embed.addFields([
                                {
                                    name: `${track.name}`,
                                    value: `・play count: ${track.playcount}`,
                                },
                            ]);
                        }
                        pages.push(embed);
                    }

                    let row = new Discord.ActionRowBuilder().setComponents(
                        new Discord.ButtonBuilder()
                            .setCustomId(`page-back`)
                            .setStyle(2)
                            .setEmoji(client.emoji.left)
                            .setDisabled(true),
                        new Discord.ButtonBuilder()
                            .setCustomId(`page-close`)
                            .setStyle(4)
                            .setEmoji(client.emoji.close),
                        new Discord.ButtonBuilder()
                            .setCustomId(`page-next`)
                            .setStyle(2)
                            .setEmoji(client.emoji.right)
                            .setDisabled(true)
                    );

                    const msg = await message.reply({
                        embeds: [pages[0]],
                        components: [row],
                    });

                    return client.paginator(pages, 0, row, message, msg);
                } catch (error) {
                    console.log(error);
                    const embed = new Discord.EmbedBuilder()
                        .setColor('Red')
                        .setDescription(
                            `${message.author}, i can't find your \`last.fm\` account, try using command again or report this on our discord support server.`
                        );
                    return message.reply({
                        embeds: [embed],
                    });
                }
            default:
                try {
                    const response = await axios.get(
                        'http://ws.audioscrobbler.com/2.0/',
                        {
                            params: {
                                api_key: client.config.lastfm.key,
                                method: 'user.getRecentTracks',
                                user: fm_user.lastfm,
                                format: 'json',
                            },
                        }
                    );

                    const response2 = await axios.get(
                        'http://ws.audioscrobbler.com/2.0/',
                        {
                            params: {
                                api_key: client.config.lastfm.key,
                                method: 'user.getInfo',
                                user: fm_user.lastfm,
                                format: 'json',
                            },
                        }
                    );

                    const data = response.data.recenttracks.track[0];
                    const embed = new Discord.EmbedBuilder()
                        .setColor(client.config.color)
                        .setDescription(
                            `${message.author}, your recent track info.`
                        )
                        .setThumbnail(data?.image[3]['#text'] || null)
                        .addFields([
                            {
                                name: data.name,
                                value: `by [${data.artist['#text']}](${data.url}) in [${data.album['#text']}](${data.url})`,
                            },
                        ]);
                    if (data['@attr']?.nowplaying === 'true') {
                        embed.setFooter({
                            text: `▶️ Currently playing・Scrobbles: ${response2.data.user.playcount}`,
                        });
                    } else {
                        embed.setFooter({
                            text: `⏹ Last played・Scrobbles: ${response2.data.user.playcount}`,
                        });
                    }

                    return message.reply({
                        embeds: [embed],
                    });
                } catch (error) {
                    console.log(error);
                    const embed = new Discord.EmbedBuilder()
                        .setColor('Red')
                        .setDescription(
                            `${message.author}, i can't find your \`last.fm\` account, try using command again or report this on our discord support server.`
                        );
                    return message.reply({
                        embeds: [embed],
                    });
                }
        }
    },
};
