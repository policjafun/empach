const Discord = require('discord.js');
module.exports = {
    name: 'botinfo',
    aliases: ['bi', 'bot', 'uptime'],
    description: 'Display bot informations',
    userPerms: [],
    botPerms: [],
    usage: ['botinfo'],
    run: async (client, message, args) => {
        let totalSeconds = client.uptime / 1000;
        let days = Math.floor(totalSeconds / 86400);
        totalSeconds %= 86400;
        let hours = Math.floor(totalSeconds / 3600);
        totalSeconds %= 3600;
        let minutes = Math.floor(totalSeconds / 60);
        let seconds = Math.floor(totalSeconds % 60);



        const embed = new Discord.EmbedBuilder()
            .setAuthor({
                name: client.user.username,
                iconURL: client.user.avatarURL(),
            })
            .setDescription('*Currently displays information about the bot.*')
            .addFields([
                {
                    name: 'Global',
                    value: `・Owner: <@401754404702650378> (Vylaz#2954)\n・Created: <t:${parseInt(
                        client.user.createdTimestamp / 1000
                    ).toFixed(0)}:R> (<t:${parseInt(
                        client.user.createdTimestamp / 1000
                    ).toFixed(0)}:D>)\n・Joined: <t:${parseInt(
                        message.guild.joinedTimestamp / 1000
                    ).toFixed(0)}:R> (<t:${parseInt(
                        message.guild.joinedTimestamp / 1000
                    ).toFixed(0)}:D>)\n・Uptime: ${days} days, ${hours} hours, ${minutes} minutes and ${seconds} seconds`,
                },
                {
                    name: 'Stats',
                    value: `・Channels: \`${
                        client.channels.cache.size
                    }\`\n・Guilds: \`${
                        client.guilds.cache.size
                    }\`\n・Users: \`${client.guilds.cache.reduce(
                        (acc, guild) => acc + guild.memberCount,
                        0
                    )}\` (${client.users.cache.size} cached)`,
                },
            ])
            .setThumbnail(client.user.avatarURL())
            .setColor(client.config.color);
        message.reply({
            embeds: [embed],
        });
    },
};
