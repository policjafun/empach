const { EmbedBuilder, ChannelType } = require("discord.js");
module.exports = {
    name: 'serverinfo',
    aliases: ['si', 'server'],
    description: 'Server informations lookup',
    userPerms: [],
    botPerms: [],
    usage: [''],
    run: async (client, message, args) => {
        // Useless
        const owner = await message.guild.fetchOwner();
        const description = message.guild.description;
        // Members
        const members = message.guild.members.cache.size;
        const online = message.guild.members.cache.filter(
            (member) => member.presence?.status === 'online'
        ).size;
        const dnd = message.guild.members.cache.filter(
            (member) => member.presence?.status === 'dnd'
        ).size;
        const idle = message.guild.members.cache.filter(
            (member) => member.presence?.status === 'idle'
        ).size;
        const offline = message.guild.members.cache.filter(
            (member) => member.presence?.status === 'offline'
        ).size;
        // Channels
        const channels = message.guild.channels.cache.size;
        const text = message.guild.channels.cache.filter(
            (channel) => channel.type === ChannelType.GuildText
        ).size;
        const voice = message.guild.channels.cache.filter(
            (channel) => channel.type === ChannelType.GuildVoice
        ).size;
        const category = message.guild.channels.cache.filter(
            (channel) => channel.type === ChannelType.GuildCategory
        ).size;
        // Emojis
        const emojis = message.guild.emojis.cache.size;
        const static = message.guild.emojis.cache.filter(
            (m) => !m.animated
        ).size;
        const animated = message.guild.emojis.cache.filter(
            (m) => m.animated
        ).size;
        // Roles
        const roles = message.guild.roles.cache.size;
        // Boosts
        const level = message.guild.premiumTier;
        const boosts = message.guild.premiumSubscriptionCount || '0';
        const embed = new EmbedBuilder().setAuthor({
            name: message.guild.name,
            iconURL: message.guild.iconURL({ dynamic: true }),
        });
        if (description) {
            embed.setDescription(description);
        }
        embed
            .addFields([
                {
                    name: 'Global',
                    value: `・Owner: <@${owner.id}> (${
                        owner.id
                    })\n・Created: <t:${parseInt(
                        message.guild.createdAt / 1000
                    )}:R> (<t:${parseInt(
                        message.guild.createdAt / 1000
                    )}:D>)\n・Members: \` ${members} \` (${online} online, ${dnd} dnd, ${idle} idle, ${offline} offline)\n・Channels: \` ${channels} \` (${text} text, ${voice} voice, ${category} category)\n・Emojis: \` ${emojis} \` (${static} static, ${animated} animated)\n・Level: \` ${level} \` (${boosts} boosts)\n・Roles: \` ${roles} \``,
                },
            ])
            .setThumbnail(message.guild.iconURL({ dynamic: true }))
            .setColor(client.config.color);
        message.reply({
            embeds: [embed],
        });
    },
};
