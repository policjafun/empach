const Discord = require('discord.js');
module.exports = {
    name: 'kick',
    description: 'Kick member',
    userPerms: ['KickMembers'],
    botPerms: ['KickMembers'],
    usage: ['kick <@member> [reason]'],
    run: async (client, message, args) => {
        if (!args[0]) return args.usage('kick');

        let user;
        try {
            if (args[0]) {
                user =
                    message.mentions.users.first() ||
                    client.users.cache.find((u) =>
                        u.username.toLowerCase().includes(args[0].toLowerCase())
                    ) ||
                    (await client.users.fetch(args[0]));
            } else {
                user = message.author;
            }
        } catch (err) {
            const embed = new Discord.EmbedBuilder()
                .setColor('Red')
                .setDescription(
                    `*${message.member}, i cant find that user!*`
                );

            return message.reply({
                embeds: [embed],
            });
        }
        await user.fetch();
        const guildMember = message.guild.members.cache.get(user.id);

        if (user.id === message.author.id) {
            const embed = new Discord.EmbedBuilder()
                .setColor('Red')
                .setDescription(
                    `*${message.member}, you cannot kick yourself!*`
                );

            return message.reply({
                embeds: [embed],
            });
        }

        if (!guildMember.kickable) {
            const embed = new Discord.EmbedBuilder()
                .setColor('Red')
                .setDescription(
                    `*${message.member}, i cant kick this user!*`
                );

            return message.reply({
                embeds: [embed],
            });
        }

        if (
            guildMember.roles.highest.position >=
            message.member.roles.highest.position
        ) {
            const embed = new Discord.EmbedBuilder()
                .setColor('Red')
                .setDescription(
                    `*${message.member}, this user has higher roles than you, i cant kick him!*`
                );

            return message.reply({
                embeds: [embed],
            });
        }

        const embedDM = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(
                `<@${user.id}>, you've got kicked from server \`${message.guild.name}\``
            )
            .addFields({
                name: 'details',
                value: `・admin: <@${message.author.id}> (${
                    message.author.id
                })\n・reason: ${
                    args.slice(1)?.join(' ') || 'no reason provided'
                }`,
            });

        try {
            user.send({
                embeds: [embedDM],
            });
        } catch (e) {}

        const embedChannel = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(
                `${message.member}, you've kicked <@${user.id}> (${user.id})`
            )
            .addFields({
                name: 'details',
                value: `・admin: ${message.member} (${
                    message.author.id
                })\n・reason: ${
                    args.slice(1)?.join(' ') || 'no reason provided'
                }`,
            });

        message.reply({
            embeds: [embedChannel],
        });

        guildMember.kick(
            args.slice(1).join(' ')
                ? args.slice(1).join(' ')
                : `Kicked by ${message.author.tag} (${message.author.id}). Reason not provided.`
        );
    },
};
