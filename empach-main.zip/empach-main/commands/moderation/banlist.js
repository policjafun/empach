const Discord = require('discord.js');
module.exports = {
    name: 'banlist',
    aliases: ['blist', 'bl', 'bans'],
    description: 'Shows ban list on this server',
    userPerms: [],
    botPerms: ['BanMembers'],
    usage: ['banlist'],
    run: async (client, message, args) => {
        message.guild.bans.fetch().then(async (bans) => {
            let arr = [];
            bans.map((bans) =>
                arr.push({
                    tag: bans.user.tag,
                    reason: bans.reason,
                })
            );

            let list = arr;

            if (list.length == 0) {
                return args.error('No bans found on this guild!');
            }

            const pages = [];
            const chunkSize = 10;
            for (let i = 0; i < list.length; i += chunkSize) {
                const chunk = list.slice(i, i + chunkSize);

                const embed = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription(
                        `${message.member}, here are the full list of bans on \`${message.guild.name}\``
                    );

                for (const bans of chunk) {
                    embed.addFields([
                        {
                            name: `${bans.tag}`,
                            value: `・Reason: \`${
                                bans.reason || 'no reason'
                            }\``,
                        },
                    ]);
                }
                pages.push(embed);
            }

            let row = new Discord.ActionRowBuilder().setComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`page-back`)
                    .setStyle(2)
                    .setEmoji(client.emoji.left)
                    .setDisabled(true),
                new Discord.ButtonBuilder()
                    .setCustomId(`page-close`)
                    .setStyle(4)
                    .setEmoji(client.emoji.close),
                new Discord.ButtonBuilder()
                    .setCustomId(`page-next`)
                    .setStyle(2)
                    .setEmoji(client.emoji.right)
                    .setDisabled(true)
            );

            const msg = await message.reply({
                embeds: [pages[0]],
                components: [row],
            });

            return client.paginator(pages, 0, row, message, msg);
        });
    },
};
