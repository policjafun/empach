const Discord = require('discord.js');
module.exports = {
    name: 'ban',
    description: 'Ban member',
    userPerms: ['BanMembers'],
    botPerms: ['BanMembers'],
    usage: ['ban <@member> [reason]'],
    run: async (client, message, args) => {
        if (!args[0]) return args.usage('ban');

        let user;
        try {
            if (args[0]) {
                user =
                    message.mentions.users.first() ||
                    client.users.cache.find((u) =>
                        u.username.toLowerCase().includes(args[0].toLowerCase())
                    ) ||
                    (await client.users.fetch(args[0]));
            } else {
                user = message.author;
            }
        } catch (err) {
            return args.error("No user found.")
        }
        await user.fetch();
        const guildMember = message.guild.members.cache.get(user.id);

        if (guildMember) {
            if (user.id === message.author.id) {
                return args.error("You cannot ban yourself.")
            }

            if (!guildMember.bannable) {
                return args.error("I can't ban this user")
            }

            if (
                guildMember.roles.highest.position >=
                message.member.roles.highest.position
            ) {
                return args.error("This user has higher role ")
            }
        }

        const embedDM = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(
                `<@${user.id}>, you've got banned from server \`${message.guild.name}\``
            )
            .addFields({
                name: 'details',
                value: `・admin: <@${message.author.id}> (${
                    message.author.id
                })\n・reason: ${
                    args.slice(1)?.join(' ') || 'no reason provided'
                }`,
            });

        try {
            user.send({
                embeds: [embedDM],
            });
        } catch (e) {}

        const embedChannel = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(
                `${message.member}, you've banned <@${user.id}> (${user.id})`
            )
            .addFields({
                name: 'details',
                value: `・admin: ${message.member} (${
                    message.author.id
                })\n・reason: ${
                    args.slice(1)?.join(' ') || 'no reason provided'
                }`,
            });

        message.reply({
            embeds: [embedChannel],
        });

        message.guild.bans.create(user.id, {
            reason: args.slice(1).join(' ')
                ? args.slice(1).join(' ')
                : `Banned by ${message.author.tag} (${message.author.id}). Reason not provided.`,
        });
    },
};
