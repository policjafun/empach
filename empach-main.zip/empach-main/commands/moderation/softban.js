const Discord = require('discord.js');
module.exports = {
    name: 'softban',
    description: 'Ban member and delete all messages',
    userPerms: ['BanMembers'],
    botPerms: ['BanMembers'],
    usage: ['softban <@member> [reason]'],
    run: async (client, message, args) => {
        if (!args[0]) return args.usage('ban');

        let user;
        try {
            if (args[0]) {
                user =
                    message.mentions.users.first() ||
                    client.users.cache.find((u) =>
                        u.username.toLowerCase().includes(args[0].toLowerCase())
                    ) ||
                    (await client.users.fetch(args[0]));
            } else {
                user = message.author;
            }
        } catch (err) {
            const embed = new Discord.EmbedBuilder()
                .setColor('Red')
                .setDescription(
                    `*${message.member}, i cant find that user!*`
                );

            return message.reply({
                embeds: [embed],
            });
        }
        await user.fetch();
        const guildMember = message.guild.members.cache.get(user.id);

        if (guildMember) {
            if (user.id === message.author.id) {
                const embed = new Discord.EmbedBuilder()
                    .setColor('Red')
                    .setDescription(
                        `*${message.member}, you cannot ban yourself!*`
                    );

                return message.reply({
                    embeds: [embed],
                });
            }

            if (!guildMember.bannable) {
                const embed = new Discord.EmbedBuilder()
                    .setColor('Red')
                    .setDescription(
                        `*${message.member}, i cant ban this user!*`
                    );

                return message.reply({
                    embeds: [embed],
                });
            }

            if (
                guildMember.roles.highest.position >=
                message.member.roles.highest.position
            ) {
                const embed = new Discord.EmbedBuilder()
                    .setColor('Red')
                    .setDescription(
                        `*${message.member}, this user has higher roles than you, i cant ban him!*`
                    );

                return message.reply({
                    embeds: [embed],
                });
            }
        }

        const embedDM = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(
                `<@${user.id}>, you've got banned from server \`${message.guild.name}\``
            )
            .addFields({
                name: 'details',
                value: `・admin: <@${message.author.id}> (${
                    message.author.id
                })\n・reason: ${
                    args.slice(1)?.join(' ') || 'no reason provided'
                }`,
            });

        try {
            user.send({
                embeds: [embedDM],
            });
        } catch (e) {}

        const embedChannel = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(
                `${message.member}, you've banned <@${user.id}> (${user.id})`
            )
            .addFields({
                name: 'details',
                value: `・admin: ${message.member} (${
                    message.author.id
                })\n・reason: ${
                    args.slice(1)?.join(' ') || 'no reason provided'
                }`,
            });

        message.reply({
            embeds: [embedChannel],
        });

        message.guild.bans.create(user.id, {
            reason: args.slice(1).join(' ')
                ? args.slice(1).join(' ')
                : `Banned by ${message.author.tag} (${message.author.id}). Reason not provided.`,
            deleteMessageDays: 7
        });
    },
};