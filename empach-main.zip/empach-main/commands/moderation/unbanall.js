const Discord = require('discord.js');
module.exports = {
    name: 'unbanall',
    aliases: ['massunban', 'allunban'],
    description: '',
    userPerms: ['BanMembers'],
    botPerms: ['ManageGuild', 'BanMembers'],
    usage: ['unbanall'],
    run: async (client, message, args) => {
        message.guild.bans.fetch().then(async bans => {
            if(bans.size === 0) return args.error("There are no bans in current guild.")

            const embed = new Discord.EmbedBuilder()
                .setColor(client.config.color)
                .setDescription(`*${message.member}, starting process.*`)

            let msg = await message.reply({
                embeds: [embed]
            })

            bans.forEach(async ban => {
                await message.guild.members.unban(ban.user.id)
            })

            msg.edit({
                embeds: [embed.setDescription(`*${message.member}, process ended up with no errors*`)]
            })
        })
    },
};
