const Discord = require('discord.js');

module.exports = {
    name: 'jail',
    description: 'Jail a user',
    userPerms: ['ManageRoles'],
    botPerms: ['ManageRoles'],
    usage: ['jail <user>'],
    run: async (client, message, args) => {
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!user) return args.usage('jail');

        const role = await client.db.jailConfig.findOne({ guildId: message.guild.id })
        if (!role || !role?.jailRole) return args.error('Jail role does not exist');

        if(user.permissions.has('ManageRoles')) return args.error('User has `ManageRoles` permission');
        if (user.roles.highest.position >= message.member.roles.highest.position) return args.error('User is higher than you');
        if (user.roles.cache.has(role.id)) return args.error('User is already jailed');

        let roleFetch = await message.guild.roles.fetch(role.jailRole)
        if (!roleFetch) return args.error('Jail role does not exist!');

        let c = await client.schemas.jailUserRoles.findOne({
            userId: user.id
        })

        if(!c)
            c = new client.schemas.jailUserRoles({
                userId: user.id,
                rolesId: []
            })

        user.roles.forEach(role => {
            c.rolesId.push(role.id)

            user.roles.remove(role)
        })

        await c.save()

        await user.roles.add(role.jailRole);
        return args.success(`Successfully jailed ${user.user.tag}`);
    }
}