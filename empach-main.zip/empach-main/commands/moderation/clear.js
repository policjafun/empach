const Discord = require('discord.js');
module.exports = {
    name: 'clear',
    aliases: ['purge'],
    description: 'Clears given amount of messages in channel',
    userPerms: ['ManageMessages'],
    botPerms: ['ManageMessages'],
    usage: ['clear <amount (from 1 to 100)>'],
    run: async (client, message, args) => {
        if(!args[0]) return args.usage('clear')

        const amount = parseInt(args[0])

        if(amount > 100 || amount < 1) {
            return args.usage("clear")
        }

        await message.channel.bulkDelete(amount + 1)

        const embedChannel = new Discord.EmbedBuilder()
        .setColor(client.config.color)
        .setDescription(
            `*${message.member}, successfully deleted messages*`
        )
        .addFields({
            name: 'details',
            value: `・messages count: \`${parseInt(args[0])}\`\n・channel: <#${message.channel.id}>`,
        });

        message.channel.send({
            embeds: [embedChannel]
        }).then(msg => {
            setTimeout(() => {
                msg.delete()
            }, 4000)
        })
    },
};
