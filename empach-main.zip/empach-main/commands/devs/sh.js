const Discord = require('discord.js');
const {
    exec
} = require('child_process')
module.exports = {
    name: 'sh',
    aliases: ['exec'],
    description: '',
    userPerms: [],
    botPerms: [],
    usage: [''],
    developerOnly: true,
    run: async (client, message, args) => {
        exec(args.join(" "), (error, stdout) => {
            let res = (error || stdout);
            if(error) {
                args.error(`Something went wrong:\n\n${error}`)
                return console.log(error)
            }
            args.success(`Successfully executed command in console:\n\n\`\`\`${res}\`\`\``)
            return console.log(res)
        })
    },
};
