const Discord = require('discord.js');
const { exec } = require('child_process')
module.exports = {
    name: 'restart',
    description: 'Restart bot instance',
    userPerms: [],
    botPerms: [],
    developerOnly: true,
    run: async (client, message, args) => {
        return exec("pm2 restart 0", (error, stdout) => {
            args.success(`Restarted bot instance`)
        })
    },
};
