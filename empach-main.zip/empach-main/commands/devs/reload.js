const Discord = require('discord.js');
module.exports = {
    name: 'reload',
    aliases: ['rl'],
    description: 'Reloads commands',
    userPerms: [],
    botPerms: [],
    developerOnly: true,
    usage: ['reload'],
    run: async (client, message, args) => {
        require('../../handlers/command')(client);
        return args.success(
            args[0] !== '*'
                ? `Reloaded \`empach.commands.${args[0] || "*"}\``
                : `Reloaded \`empach.commands.*\``
        );
    },
};
