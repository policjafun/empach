const Discord = require('discord.js');

module.exports = {
    name: 'maintenance',
    aliases: ['maintain', 'maintenance'],
    description: 'Enable or disable maintenance mode',
    developerOnly: true,
    userPerms: [],
    botPerms: [],
    usage: ['maintenance <enable/disable>'],
    run: async (client, message, args) => {
        if (!args[0]) return args.usage('maintenance');

        if (args[0] === 'enable') {
            client.maintenance = true;

            args.success('Sucessfully enabled maintenance mode.');
        } else if (args[0] === 'disable') {
            client.maintenance = false;

            args.success('Sucessfully disabled maintenance mode.');
        } else {
            return args.usage('maintenance');
        }
    }
}