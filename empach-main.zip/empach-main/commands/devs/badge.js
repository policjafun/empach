const Discord = require('discord.js');
module.exports = {
    name: 'badge',
    aliases: ['manage-badges', 'badges'],
    description: '',
    userPerms: [],
    botPerms: [],
    usage: ['badge <add|remove> <@member> <badge name>'],
    developerOnly: true,
    run: async (client, message, args) => {
        if(!args[1]) return args.usage('badge')
        let user;
        try {
            if (args[1]) {
                user =
                    message.mentions.users.first() ||
                    client.users.cache.find((u) =>
                        u.username.toLowerCase().includes(args[1].toLowerCase())
                    ) ||
                    (await client.users.fetch(args[1]));
            } else {
                user = message.author;
            }
        } catch (err) {
            const embed = new Discord.EmbedBuilder()
                .setColor('Red')
                .setDescription(
                    `*${message.member}, i cant find that user!*`
                );

            return message.reply({
                embeds: [embed],
            });
        }

        switch (args[0]) {
            case 'add':
                if (!args[2]) {
                    return args.usage('badge');
                }
                if (!Object.keys(client.config.badges).includes(args[2])) {
                    const embed = new Discord.EmbedBuilder()
                        .setColor('Red')
                        .setDescription(
                            `*${message.member}, cant find that badge!*`
                        );

                    return message.reply({
                        embeds: [embed],
                    });
                }

                let badgeFound = await client.db.badges.findOne({
                    id: user.id,
                });

                if (badgeFound.badges.includes(args[2])) {
                    const embed = new Discord.EmbedBuilder()
                        .setColor('Red')
                        .setDescription(
                            `*${message.member}, this user alredy have this badge!*`
                        );

                    return message.reply({
                        embeds: [embed],
                    });
                }

                const embedAdded = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription(
                        `${message.member}, added badge ${
                            client.config.badges[args[2]]
                        } (${args[2]}) to ${user} (${user.id}) successfully!`
                    );

                message.reply({
                    embeds: [embedAdded],
                });

                badgeFound.badges.push(args[2]);

                await badgeFound.save();
                break;
            case 'remove':
                if (!args[2]) {
                    return args.usage('badge');
                }
                if (!Object.keys(client.config.badges).includes(args[2])) {
                    const embed = new Discord.EmbedBuilder()
                        .setColor('Red')
                        .setDescription(
                            `*${message.member}, cant find that badge!*`
                        );

                    return message.reply({
                        embeds: [embed],
                    });
                }

                let badgeFoundToDel = await client.db.badges.findOne({
                    id: user.id,
                });

                if (!badgeFoundToDel.badges.includes(args[2])) {
                    const embed = new Discord.EmbedBuilder()
                        .setColor('Red')
                        .setDescription(
                            `*${message.member}, this user doesnt have this badge!*`
                        );

                    return message.reply({
                        embeds: [embed],
                    });
                }

                badgeFoundToDel.badges.pull(args[2]);

                const embedRemove = new Discord.EmbedBuilder()
                    .setColor(client.config.color)
                    .setDescription(
                        `${
                            message.member
                        }, removed badge ${client.config.badges[args[2]]} (${
                            args[2]
                        }) from ${user} (${user.id}) successfully!`
                    );

                message.reply({
                    embeds: [embedRemove],
                });

                await badgeFoundToDel.save();
                break;
            case 'list':
                let badgeFoundToList = await client.db.badges.findOne({
                    id: user.id,
                });

                return message.reply({
                    content: badgeFoundToList.badges.join(' '),
                });
            default:
                return args.usage('badge');
        }
    },
};
