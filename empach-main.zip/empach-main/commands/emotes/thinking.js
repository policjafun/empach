const emotes = require('./emotes.json');
const Discord = require('discord.js');

module.exports = {
    name: 'thinking',
    aliases: ['think', 'thinks'],
    description: 'Thinks',
    userPerms: [],
    botPerms: [],
    usage: ['thinking'],
    run: async (client, message, args) => {
        let array = emotes.thinking.msg;
        let random = array[Math.floor(Math.random() * array.length)];
        let embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(random
                .replace("?", message.member));

        message.reply({
            embeds: [embed]
        })
    }
}