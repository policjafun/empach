const emotes = require('./emotes.json');
const Discord = require('discord.js');

module.exports = {
    name: 'sleepy',
    aliases: ['sleep'],
    description: 'Sleep Emoji',
    userPerms: [],
    botPerms: [],
    usage: ['sleepy'],
    run: async (client, message, args) => {
        let array = emotes.sleepy.msg;
        let random = array[Math.floor(Math.random() * array.length)];
        let embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(random
                .replace("?", message.member));

        message.reply({
            embeds: [embed]
        })
    }
}