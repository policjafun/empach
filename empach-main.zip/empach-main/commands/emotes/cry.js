const emotes = require('./emotes.json');
const Discord = require('discord.js');

module.exports = {
    name: 'cry',
    aliases: ['cries'],
    description: 'Cries',
    userPerms: [],
    botPerms: [],
    usage: ['cry'],
    run: async (client, message, args) => {
        let array = emotes.cry.msg;
        let random = array[Math.floor(Math.random() * array.length)];
        let embed = new Discord.EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(random
                .replace("?", message.member));

        message.reply({
            embeds: [embed]
        })
    }
}