const Discord = require('discord.js');
module.exports = {
    name: '',
    aliases: [''],
    description: '',
    userPerms: [],
    botPerms: [],
    usage: [''],
    run: async (client, message, args) => {},
};
