module.exports = {
    check: async (client, message) => {
        let inf = await client.db.prefix.findOne({
            guildId: message.guildId,
        });
    
        let bdg = await client.db.badges.findOne({
            id: message.author.id,
        });
    
        if (!bdg) {
            await client.db.badges.create({
                id: message.author.id,
            });
        }
    
        if (!inf)
            inf = await client.db.prefix.create({
                guildId: message.guildId,
                prefixes: [`pls`],
            });
    
        await inf.save();
    
        let prf = null; //debug
        for (let prefix of inf.prefixes) {
            if (message.content.startsWith(prefix)) prf = prefix;
        }
    
        if (
            message.content.startsWith(`<@${client.user.id}>`) ||
            message.content.startsWith(`<@!${client.user.id}>`)
        )
            prf = `ping`;
    
        if (!prf) return;
    
        message.prefix = prf.replace('ping', `@${client.user.username} `);
    
        if (prf === `ping`) {
            message.mentions.members?.delete(client.user.id);
            message.mentions.users?.delete(client.user.id);
            message.content = message.content
                .replace(`<@${client.user.id}>`, ``)
                .replace(`<@!${client.user.id}>`, ``);
        }
    
        message.content = message.content.replace(prf, ``);
        if (message.content.startsWith(` `))
            message.content = message.content.replace(` `, ``);
        let args = message.content.split(` `);
        let cmd = args.shift().toLowerCase();
    
        let command =
            client.commands.get(cmd) ||
            client.commands.get(client.aliases.get(cmd));
        
        if(command) return true
        else return false
    }
}