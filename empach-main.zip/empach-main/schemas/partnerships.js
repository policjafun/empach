const mongoose = require(`mongoose`);
const Schema = mongoose.Schema;

const partnerships = new Schema({
    id: String,
    status: Boolean,
    channel: String,
    message: String,
    count: Number
});

module.exports = mongoose.model(`partnerships`, partnerships);