const mongoose = require(`mongoose`);
const Schema = mongoose.Schema;

const gameWins = new Schema({
    id: String,
    find_emoji: { type: Number, default: 0 },
    hangman: { type: Number, default: 0 },
    minesweeper: { type: Number, default: 0 },
    pairs: { type: Number, default: 0 },
    rps: { type: Number, default: 0 },
    slot: { type: Number, default: 0 },
    ox: { type: Number, default: 0 },
    wordle: { type: Number, default: 0 },
});

module.exports = mongoose.model(`gamewins`, gameWins);
