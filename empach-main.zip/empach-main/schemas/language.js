const mongoose = require(`mongoose`);
const Schema = mongoose.Schema;

const langauge = new Schema({
    id: String,
    currentLang: String
});

module.exports = mongoose.model(`language`, langauge);
