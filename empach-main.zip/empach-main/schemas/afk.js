const mongoose = require('mongoose')

module.exports = mongoose.model('afk', new mongoose.Schema({
    guild: String,
    user: String,
    reason: String,
    timestamp: String,
    isAfk: Boolean,
}))