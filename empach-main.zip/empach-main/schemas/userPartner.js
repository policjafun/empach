const mongoose = require(`mongoose`)
const Schema = mongoose.Schema;

const prefixSchema = new Schema({
    id: String,
    count: Number,
    guildId: String
})

module.exports = mongoose.model(`userPartner`, prefixSchema)