const mongoose = require('mongoose')

module.exports = mongoose.model('snipe', new mongoose.Schema({
    id: String,
    user: String,
    message: String,
    channel: String,
    lastUsed: { type: Number, default: Math.floor(Date.now() / 1000) }
}))