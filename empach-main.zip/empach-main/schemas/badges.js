const mongoose = require(`mongoose`);
const Schema = mongoose.Schema;

const badges = new Schema({
    id: String,
    badges: { type: Array, default: ['user'] }
});

module.exports = mongoose.model(`badges`, badges);
