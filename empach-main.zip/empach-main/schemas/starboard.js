const mongoose = require('mongoose')

const starboard = new mongoose.Schema({
    guild: String,
    channel: String,
    count: Number
})

module.exports = mongoose.model('starboard', starboard)