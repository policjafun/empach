const mongoose = require(`mongoose`);
const Schema = mongoose.Schema;

const welcomer = new Schema({
    id: String,
    status: Boolean,
    channel: String,
    message: String,
    updatedAt: { type: Number, default: Math.floor(Date.now() / 1000) }
});

module.exports = mongoose.model(`welcomer`, welcomer);
