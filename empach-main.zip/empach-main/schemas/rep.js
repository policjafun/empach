const mongoose = require(`mongoose`);
const Schema = mongoose.Schema;

const rep = new Schema({
    id: String,
    reps: { type: Number, default: 0 },
    updatedAt: { type: Number, default: Math.floor(Date.now() / 1000) },
    givenTo: Array
});

module.exports = mongoose.model(`reps`, rep);