const mongoose = require(`mongoose`);
const Schema = mongoose.Schema;

const goodbye = new Schema({
    usersId: String,
    rolesId: Array
});

module.exports = mongoose.model(`jailUserRole`, goodbye);