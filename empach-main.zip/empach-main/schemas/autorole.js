const mongoose = require('mongoose')

module.exports = mongoose.model('autoroles', new mongoose.Schema({
    id: String,
    roles: Array
}))