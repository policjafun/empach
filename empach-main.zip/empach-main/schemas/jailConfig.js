const mongoose = require(`mongoose`);
const Schema = mongoose.Schema;

const goodbye = new Schema({
    guildId: String,
    jailRole: String
});

module.exports = mongoose.model(`jailConfig`, goodbye);