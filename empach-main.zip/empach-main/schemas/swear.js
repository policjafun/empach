const mongoose = require(`mongoose`);
const Schema = mongoose.Schema;

const swear = new Schema({
    swears: Boolean,
    id: String,
})

module.exports = mongoose.model(`swear`, swear);