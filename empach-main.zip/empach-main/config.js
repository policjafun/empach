module.exports = {
	prefix: "pls",
	color: "#f86304",
	lastfm: {
		key: "617e93ab0274fcc4d047fe0f952bf2f5"
	},
	defaultCooldown: 4000,
	badges: {
		dev: "*`empach developer`*",
		user: "*`user`*",
		trusted: "*`trusted user`*",
		staff: "*`empach staff`*",
		owner: "*`empach owner`*",
		betauser: "*`empach beta-user`*",
		bughunter: "*`bug hunter`*",
		blacklisted: "*`blacklisted`*",
		botdev: "*`verified bot developer`*"
	},
	devs: [
		"1071108000317714452",
		"842378070857875497",
		"766271467801018369"
	]
}
