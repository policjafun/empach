const fs = require('fs')

module.exports = (client) => {
    const express = require('express');
    const app = express();
    const port = 3001;

    const cors = require('cors');
    app.use(cors());

    app.get('/commands', (req, res) => {
        let subCommands = 0
        let categories = [];

        fs.readdirSync('./commands/').forEach((dir) => {
            const commands = fs
                .readdirSync(`./commands/${dir}/`)
                .filter((file) => file.endsWith('.js'));

            const cmds = commands.map((command) => {
                let file = require(`../commands/${dir}/${command}`);

                if (!file.name) return 'No command name.';

                let name = file.name.replace('.js', '');

                if (file.usage?.length !== undefined) subCommands += file.usage?.length

                return file;
            });

            let data = new Object();

            data = {
                name: dir.charAt(0).toUpperCase() + dir.slice(1),
                value: cmds.length === 0 ? 'In progress.' : cmds,
            };

            categories.push(data);
        });

        res.send(categories)
    })

    app.get('/swears', (req, res) => {
        res.send(require('./data/swears.json'))
    })

    app.get("*", (req, res) => {
        res.redirect("/commands")
    });

    app.listen(port);
}