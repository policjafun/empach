const { ComponentType } = require('discord.js');

module.exports = (client) => {
    client.emoji = {};
    client.paginator = (arr, startPage, row, message, sent) => {
        let allPages = arr.length - 1;
        let crtPage = startPage;

        arr.forEach((embed) => {
            embed.data.footer = {
                text: `Page: ${arr.indexOf(embed) + 1}/${allPages + 1}`,
            };
        });

        if (crtPage !== allPages) row.components[2].data.disabled = false;

        if (crtPage === allPages) row.components[2].data.disabled = true;

        sent.edit({
            embeds: [arr[startPage]],
            components: [row],
        });

        if (startPage > allPages)
            return new Error(`Start page cannot be bigger than all pages!`);

        const collector = message.channel.createMessageComponentCollector({
            componentType: ComponentType.Button,
            time: 60000 * 5,
            filter: (i) => i.message.id === sent.id,
        });

        collector.on(`collect`, async (i) => {
            if (i.user.id != message.author.id) {
                return i.reply({
                    content: `This interaction is not yours.`,
                    ephemeral: true,
                });
            }

            if (i.customId === 'page-back') {
                crtPage = crtPage - 1;

                if (crtPage === 0) row.components[0].data.disabled = true;

                if (crtPage !== 0) row.components[0].data.disabled = false;

                if (crtPage !== allPages)
                    row.components[2].data.disabled = false;

                if (crtPage === allPages)
                    row.components[2].data.disabled = true;

                // arr[crtPage].data.footer = { text: `Page: ${crtPage + 1}/${allPages + 1}` }

                await sent.edit({
                    embeds: [arr[crtPage]],
                    components: [row],
                });
                return i.deferUpdate();
            }

            if (i.customId === 'page-next') {
                crtPage = crtPage + 1;

                if (crtPage === 0) row.components[0].data.disabled = true;

                if (crtPage !== 0) row.components[0].data.disabled = false;

                if (crtPage !== allPages)
                    row.components[2].data.disabled = false;

                if (crtPage === allPages)
                    row.components[2].data.disabled = true;

                // arr[crtPage].data.footer = { text: `Page: ${crtPage + 1}/${allPages + 1}` }

                await sent.edit({
                    embeds: [arr[crtPage]],
                    components: [row],
                });
                return i.deferUpdate();
            }

            if (i.customId === 'page-close') {
                return collector.stop();
            }
        });

        collector.on(`end`, () => {
            sent.edit({
                content: `Interaction closed.`,
                embeds: [],
                components: [],
            });
        });
    };
    client.rasik = {
        def: true,
        skid: true,
        develope: false,
        owner: false,
        yovisek: true,
    };
    client.chunkStr = (str, size = 1500) => {
        if (typeof str === 'string') {
            const length = str.length;
            const chunks = Array(Math.ceil(length / size));
            if (length) {
                chunks[0] = str.slice(0, length % size || size);
                for (let i = 1, index = chunks[0].length; index < length; i++) {
                    chunks[i] = str.slice(index, (index += size));
                }
            }
            return chunks;
        }
    };
    client.isCmd = async (message) => {
        if (message.author.bot) return false;
        if (!message.guild) return false;

        let inf = await client.db.prefix.findOne({
            guildId: message.guildId,
        });

        if (!inf)
            inf = await client.db.prefix.create({
                guildId: message.guildId,
                prefixes: [`pls`],
            });

        await inf.save();

        let prf = null;
        for (let prefix of inf.prefixes) {
            if (message.content.startsWith(prefix)) prf = prefix;
        }

        if (
            message.content.startsWith(`<@${client.user.id}>`) ||
            message.content.startsWith(`<@!${client.user.id}>`)
        )
            prf = `ping`;

        if (!prf) return false;
        else return true;
    };
    client.getLocale = (message, string, ...vars) => {
        let { currentLang } = client.db.language.findOne({
            id: message.guild.id,
        }) || { currentLang: 'en' };
        let locale = require('../data/languages.json')[string.split('.')[0]][
            string.split('.')[1]
        ][currentLang];

        let count = 0;
        locale = locale.replace(/%VAR%/g, () =>
            vars[count] !== null ? vars[count] : '%VAR%'
        );

        return locale;
    };
};
