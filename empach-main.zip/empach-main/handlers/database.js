const { default: chalk } = require("chalk");
const fs = require(`node:fs`);

module.exports = async (client) => {
    let schemas = fs.readdirSync(`${process.cwd()}/schemas`, (err) => {
        if (err) throw new Error(err);
    });

    for (let schema of schemas) {
        let schemac = require(`${process.cwd()}/schemas/${schema}`);

        client.db[schema.replace(`.js`, ``)] = schemac;
    }

    console.log(chalk.greenBright("Loaded whole database successfully"))
};
